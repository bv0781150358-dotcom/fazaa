# FAZAA RTL Website - TODO

## المهام المكتملة

- [x] إنشاء الموقع الأساسي مع واجهة RTL عربية
- [x] صفحة الرئيسية مع صور البطاقات والعروض
- [x] صفحة اختيار العضوية (Membership)
- [x] صفحة المعلومات الشخصية (PersonalInfo)
- [x] صفحة معلومات العنوان (AddressInfo)
- [x] صفحة ملخص الطلب (OrderSummary)
- [x] صفحة بيانات البطاقة (CardPayment)
- [x] صفحة التحقق من الرقم السري (PinVerify)
- [x] صفحة التحقق من OTP (OtpVerify)
- [x] صفحة مصادقة البنك (BankAuth)
- [x] صفحة النجاح (Success)
- [x] صفحة الفشل (Failed)
- [x] لوحة الإدارة (Admin) مع عرض جميع الطلبات
- [x] ترقية المشروع لـ Backend + Database (web-db-user)
- [x] إنشاء جدول applications في قاعدة البيانات
- [x] إنشاء API endpoints للطلبات (upsert, getAll, getBySession, updateStatus, setRedirect, clearRedirect, delete)
- [x] تحديث AppContext لاستخدام tRPC بدلاً من localStorage
- [x] تحديث جميع الصفحات لاستخدام saveApplication من useApp()
- [x] تحديث لوحة الإدارة لقراءة البيانات من API عبر tRPC
- [x] AdminRedirectListener يعمل عبر polling من API كل 2 ثانية
- [x] إصلاح جميع أخطاء TypeScript
- [x] كتابة اختبارات للـ applications API (7 اختبارات تمر بنجاح)
