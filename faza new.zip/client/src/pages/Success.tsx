/* FAZAA Success Page */
import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Success() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, resetAppData } = useApp();

  useEffect(() => {
    // Mark as approved
    if (appData.id) {
      saveApplication({ ...appData, status: 'approved', currentPage: '/success' });
    }
  }, []);

  const handleHome = () => {
    resetAppData();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      <Header />

      <main className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-md text-center">
          {/* Success animation */}
          <div className="relative flex justify-center mb-8">
            <div
              className="w-28 h-28 rounded-full flex items-center justify-center success-pulse"
              style={{ background: 'rgba(109,190,69,0.1)', border: '3px solid rgba(109,190,69,0.4)' }}
            >
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #6DBE45, #4A9A2A)' }}
              >
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
              </div>
            </div>
            {/* Sparkles */}
            {[0, 60, 120, 180, 240, 300].map((deg, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 rounded-full"
                style={{
                  background: '#6DBE45',
                  top: `${50 + 55 * Math.sin(deg * Math.PI / 180)}%`,
                  left: `${50 + 55 * Math.cos(deg * Math.PI / 180)}%`,
                  transform: 'translate(-50%, -50%)',
                  opacity: 0.6,
                  animation: `pulse 2s ease-in-out ${i * 0.3}s infinite`,
                }}
              />
            ))}
          </div>

          {/* Content */}
          <div className="rounded-2xl p-8" style={{ background: '#071020', border: '1px solid rgba(109,190,69,0.2)' }}>
            <h1 className="text-2xl font-black text-white mb-3">تم استلام طلبك بنجاح</h1>
            <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.65)', fontFamily: 'Cairo, sans-serif' }}>
              شكراً لك، تم استلام طلبك بنجاح وسيتواصل معك فريق التوصيل لتحديد موعد التسليم.
            </p>

            {/* Order details */}
            {appData.fullName && (
              <div className="p-4 rounded-xl mb-6 text-right" style={{ background: 'rgba(109,190,69,0.08)', border: '1px solid rgba(109,190,69,0.15)' }}>
                <p className="text-xs mb-1" style={{ color: 'rgba(255,255,255,0.4)', fontFamily: 'Cairo, sans-serif' }}>تفاصيل الطلب</p>
                <p className="text-sm font-bold text-white">{appData.fullName}</p>
                <p className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>{appData.phone}</p>
                <p className="text-xs mt-1" style={{ color: '#6DBE45' }}>
                  عضوية {appData.membershipType === 'silver' ? 'فضية' : appData.membershipType === 'gold' ? 'ذهبية' : appData.membershipType === 'platinum' ? 'بلاتينية' : 'الأسرة'}
                </p>
              </div>
            )}

            <button
              onClick={handleHome}
              className="btn-gold w-full py-4 rounded-xl font-black text-base"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              العودة للرئيسية
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
