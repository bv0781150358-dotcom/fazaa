/* FAZAA Failed Payment Page */
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useEffect } from 'react';

export default function Failed() {
  const [, navigate] = useLocation();
  const { appData, saveApplication } = useApp();

  useEffect(() => {
    if (appData.id) {
      saveApplication({ ...appData, status: 'rejected', currentPage: '/failed' });
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#111111', fontFamily: 'Cairo, sans-serif' }}>
      <Header />

      <main className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-md text-center">
          {/* Error card */}
          <div className="rounded-2xl overflow-hidden">
            {/* Red header */}
            <div className="px-8 py-10" style={{ background: 'linear-gradient(135deg, #8B0000, #D72638)' }}>
              {/* Error icon */}
              <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(255,255,255,0.15)' }}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="15" y1="9" x2="9" y2="15"/>
                  <line x1="9" y1="9" x2="15" y2="15"/>
                </svg>
              </div>
              <h1 className="text-2xl font-black text-white">تم إدخال معلومات دفع غير صحيحة</h1>
            </div>

            {/* Body */}
            <div className="p-8" style={{ background: '#1A1A1A', border: '1px solid rgba(215,38,56,0.3)', borderTop: 'none' }}>
              <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.65)', fontFamily: 'Cairo, sans-serif' }}>
                عذراً، لم يتم قبول بطاقتك الائتمانية. يرجى التحقق من بيانات البطاقة والمحاولة مرة أخرى.
              </p>

              <div className="space-y-3">
                <button
                  onClick={() => navigate('/card-payment')}
                  className="w-full py-4 rounded-xl font-black text-base transition-all duration-200"
                  style={{
                    background: 'linear-gradient(135deg, #D72638, #8B0000)',
                    color: '#FFFFFF',
                    fontFamily: 'Cairo, sans-serif',
                    boxShadow: '0 4px 20px rgba(215,38,56,0.3)',
                  }}
                  onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 30px rgba(215,38,56,0.5)'}
                  onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 20px rgba(215,38,56,0.3)'}
                >
                  المحاولة مرة أخرى
                </button>

                <button
                  onClick={() => navigate('/')}
                  className="w-full py-3 rounded-xl font-bold text-sm transition-all duration-200"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    color: 'rgba(255,255,255,0.6)',
                    border: '1px solid rgba(255,255,255,0.1)',
                    fontFamily: 'Cairo, sans-serif',
                  }}
                >
                  العودة للرئيسية
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
