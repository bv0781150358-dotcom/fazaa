/* FAZAA Renew Membership — نموذج تجديد العضوية */
import { useState } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LoadingOverlay from '@/components/LoadingOverlay';

const MEMBERSHIP_OPTIONS = [
  { id: 'silver', label: 'الفضية' },
  { id: 'gold', label: 'الذهبية' },
  { id: 'platinum', label: 'البلاتينية' },
  { id: 'family', label: 'بطاقة الأسرة' },
];

interface FormData {
  membershipNumber: string;
  cardName: string;
  phone: string;
  currentMembership: string;
  requestedMembership: string;
}

interface Errors {
  membershipNumber?: string;
  cardName?: string;
  phone?: string;
  currentMembership?: string;
  requestedMembership?: string;
}

export default function RenewMembership() {
  const [, navigate] = useLocation();
  const { setAppData, saveApplication, isLoading, setIsLoading } = useApp();
  const [form, setForm] = useState<FormData>({
    membershipNumber: '',
    cardName: '',
    phone: '',
    currentMembership: '',
    requestedMembership: '',
  });
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const validate = (): boolean => {
    const errs: Errors = {};
    if (!form.membershipNumber.trim() || form.membershipNumber.trim().length < 4) {
      errs.membershipNumber = 'يرجى إدخال رقم العضوية الصحيح';
    }
    if (!form.cardName.trim() || form.cardName.trim().length < 3) {
      errs.cardName = 'يرجى إدخال الاسم كما هو على البطاقة';
    }
    if (!form.phone.trim() || !/^(\+971|00971|0)?[0-9]{9,10}$/.test(form.phone.replace(/\s/g, ''))) {
      errs.phone = 'يرجى إدخال رقم جوال إماراتي صحيح';
    }
    if (!form.currentMembership) {
      errs.currentMembership = 'يرجى اختيار العضوية الحالية';
    }
    if (!form.requestedMembership) {
      errs.requestedMembership = 'يرجى اختيار العضوية المطلوبة';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    const allTouched: Record<string, boolean> = {};
    Object.keys(form).forEach(k => (allTouched[k] = true));
    setTouched(allTouched);
    if (!validate()) return;

    setIsLoading(true);
    // حفظ بيانات التجديد في AppContext لاستخدامها في الخطوات التالية
    const freshData = {
      fullName: form.cardName,
      phone: form.phone,
      membershipType: form.requestedMembership as 'silver' | 'gold' | 'platinum' | 'family',
      renewalMembershipNumber: form.membershipNumber,
      currentMembershipType: form.currentMembership,
      currentPage: '/address-info',
      submittedAt: new Date().toISOString(),
    };
    setAppData(freshData);
    saveApplication(freshData).catch(console.error);

    setTimeout(() => {
      setIsLoading(false);
      navigate('/address-info');
    }, 600);
  };

  const inputStyle = (field: keyof Errors) => ({
    background: '#1A1A1A',
    border: `1px solid ${touched[field] && errors[field] ? '#D72638' : 'rgba(200,160,58,0.3)'}`,
    borderRadius: '10px',
    color: '#FFFFFF',
    fontFamily: 'Cairo, sans-serif',
    padding: '12px 16px',
    width: '100%',
    fontSize: '15px',
    outline: 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  });

  const selectStyle = (field: keyof Errors) => ({
    ...inputStyle(field),
    cursor: 'pointer',
    appearance: 'none' as const,
    WebkitAppearance: 'none' as const,
  });

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#111111', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}

      <Header />

      <main className="flex-1 py-10 px-4">
        <div className="max-w-2xl mx-auto">
          {/* Page header */}
          <div className="text-center mb-8">
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold mb-4"
              style={{ background: 'rgba(200,160,58,0.1)', border: '1px solid rgba(200,160,58,0.3)', color: '#C8A03A' }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M23 4v6h-6" />
                <path d="M1 20v-6h6" />
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
              </svg>
              تجديد العضوية
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">تجديد عضوية فزعة</h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.5)' }}>أدخل بياناتك لتجديد أو ترقية عضويتك</p>
          </div>

          {/* Steps indicator */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {[
              { num: 1, label: 'بيانات التجديد', active: true },
              { num: 2, label: 'العنوان', active: false },
              { num: 3, label: 'الدفع', active: false },
            ].map((step, i) => (
              <div key={step.num} className="flex items-center gap-2">
                <div className="flex flex-col items-center">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                    style={{
                      background: step.active ? 'linear-gradient(135deg, #C8A03A, #A9821D)' : 'rgba(255,255,255,0.1)',
                      color: step.active ? '#111' : 'rgba(255,255,255,0.4)',
                    }}
                  >
                    {step.num}
                  </div>
                  <span className="text-xs mt-1" style={{ color: step.active ? '#C8A03A' : 'rgba(255,255,255,0.4)', fontFamily: 'Cairo, sans-serif' }}>
                    {step.label}
                  </span>
                </div>
                {i < 2 && (
                  <div className="w-10 h-px mb-5" style={{ background: 'rgba(200,160,58,0.2)' }} />
                )}
              </div>
            ))}
          </div>

          <div className="gold-divider mb-8" />

          {/* Form card */}
          <div
            className="rounded-2xl p-6 sm:p-8"
            style={{ background: '#1A1A1A', border: '1px solid rgba(200,160,58,0.2)' }}
          >
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <span
                className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)', color: '#111' }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                  <path d="M23 4v6h-6" /><path d="M1 20v-6h6" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                </svg>
              </span>
              بيانات التجديد
            </h2>

            <div className="space-y-5">
              {/* Membership Number */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  رقم العضوية <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="أدخل رقم عضويتك الحالية"
                  value={form.membershipNumber}
                  onChange={e => {
                    setForm(p => ({ ...p, membershipNumber: e.target.value }));
                    if (touched.membershipNumber) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, membershipNumber: true })); validate(); }}
                  style={{ ...inputStyle('membershipNumber'), direction: 'ltr', textAlign: 'right' }}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                  onBlurCapture={e => { e.currentTarget.style.boxShadow = 'none'; }}
                />
                {touched.membershipNumber && errors.membershipNumber && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.membershipNumber}</p>
                )}
              </div>

              {/* Card Name */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  الاسم على البطاقة <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="أدخل الاسم كما هو مكتوب على البطاقة"
                  value={form.cardName}
                  onChange={e => {
                    setForm(p => ({ ...p, cardName: e.target.value }));
                    if (touched.cardName) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, cardName: true })); validate(); }}
                  style={inputStyle('cardName')}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                  onBlurCapture={e => { e.currentTarget.style.boxShadow = 'none'; }}
                />
                {touched.cardName && errors.cardName && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.cardName}</p>
                )}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  رقم الجوال <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="tel"
                  placeholder="05XXXXXXXX"
                  value={form.phone}
                  onChange={e => {
                    setForm(p => ({ ...p, phone: e.target.value }));
                    if (touched.phone) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, phone: true })); validate(); }}
                  style={{ ...inputStyle('phone'), direction: 'ltr', textAlign: 'right' }}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                  onBlurCapture={e => { e.currentTarget.style.boxShadow = 'none'; }}
                />
                {touched.phone && errors.phone && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.phone}</p>
                )}
              </div>

              {/* Current Membership */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  العضوية الحالية <span style={{ color: '#D72638' }}>*</span>
                </label>
                <div className="relative">
                  <select
                    value={form.currentMembership}
                    onChange={e => {
                      setForm(p => ({ ...p, currentMembership: e.target.value }));
                      if (touched.currentMembership) validate();
                    }}
                    onBlur={() => { setTouched(p => ({ ...p, currentMembership: true })); validate(); }}
                    style={selectStyle('currentMembership')}
                    onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                    onBlurCapture={e => { e.currentTarget.style.boxShadow = 'none'; }}
                  >
                    <option value="" disabled style={{ background: '#1A1A1A', color: 'rgba(255,255,255,0.4)' }}>اختر العضوية الحالية</option>
                    {MEMBERSHIP_OPTIONS.map(opt => (
                      <option key={opt.id} value={opt.id} style={{ background: '#1A1A1A', color: '#fff' }}>{opt.label}</option>
                    ))}
                  </select>
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(200,160,58,0.7)" strokeWidth="2.5">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </div>
                </div>
                {touched.currentMembership && errors.currentMembership && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.currentMembership}</p>
                )}
              </div>

              {/* Requested Membership */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  العضوية المطلوبة <span style={{ color: '#D72638' }}>*</span>
                </label>
                <div className="relative">
                  <select
                    value={form.requestedMembership}
                    onChange={e => {
                      setForm(p => ({ ...p, requestedMembership: e.target.value }));
                      if (touched.requestedMembership) validate();
                    }}
                    onBlur={() => { setTouched(p => ({ ...p, requestedMembership: true })); validate(); }}
                    style={selectStyle('requestedMembership')}
                    onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                    onBlurCapture={e => { e.currentTarget.style.boxShadow = 'none'; }}
                  >
                    <option value="" disabled style={{ background: '#1A1A1A', color: 'rgba(255,255,255,0.4)' }}>اختر العضوية المطلوبة</option>
                    {MEMBERSHIP_OPTIONS.map(opt => (
                      <option key={opt.id} value={opt.id} style={{ background: '#1A1A1A', color: '#fff' }}>{opt.label}</option>
                    ))}
                  </select>
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(200,160,58,0.7)" strokeWidth="2.5">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </div>
                </div>
                {touched.requestedMembership && errors.requestedMembership && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.requestedMembership}</p>
                )}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-200"
              style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M9 18l6-6-6-6" />
              </svg>
              رجوع
            </button>

            <button
              onClick={handleNext}
              className="btn-gold flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-sm"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              متابعة
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
