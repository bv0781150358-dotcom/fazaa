/* FAZAA Home Page — Emirates Premium Banking + Dark Gold
   Hero section, membership cards, benefits section */
import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LoadingOverlay from '@/components/LoadingOverlay';

const HERO_IMG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/hero-family-2SSnWx5PxWM8UCinSqnFZY.webp';
const PLATINUM_IMG = '/manus-storage/card-black-platinum_b4048e78.jpg';
const GOLD_IMG = '/manus-storage/card-gold_67f73f9e.jpg';
const SILVER_IMG = '/manus-storage/card-silver_bde81caa.jpg';
const FAMILY_IMG = '/manus-storage/card-family_c575ca14.jpg';

const membershipTypes = [
  { id: 'platinum', label: 'بلاتينية', en: 'Platinum', img: PLATINUM_IMG, color: '#C8A03A', desc: 'أعلى مستوى من المزايا والامتيازات الحصرية لأصحاب الطموح' },
  { id: 'gold', label: 'ذهبية', en: 'Gold', img: GOLD_IMG, color: '#E8C060', desc: 'مزايا ذهبية متميزة تناسب أسلوب حياتك الراقي' },
  { id: 'silver', label: 'فضية', en: 'Silver', img: SILVER_IMG, color: '#C0C0C0', desc: 'بداية رحلتك نحو عالم المزايا والخصومات المتنوعة' },
  { id: 'family', label: 'بطاقة الأسرة', en: 'Family', img: FAMILY_IMG, color: '#C8A03A', desc: 'عضوية شاملة لجميع أفراد الأسرة بمزايا مشتركة' },
];

const benefits = [
  {
    id: 'platinum',
    title: 'العضوية البلاتينية',
    img: PLATINUM_IMG,
    color: '#C8A03A',
    gradient: 'linear-gradient(135deg, #1A1A1A, #222)',
    borderColor: '#C8A03A',
    desc: 'استمتع بأرقى المزايا والخصومات الحصرية في أفضل المطاعم والفنادق والمراكز الترفيهية في الإمارات.',
    features: ['خصم حتى 50% في المطاعم المميزة', 'دخول مجاني لصالات المطارات', 'أولوية في الحجوزات', 'خدمة عملاء VIP'],
  },
  {
    id: 'gold',
    title: 'العضوية الذهبية',
    img: GOLD_IMG,
    color: '#E8C060',
    gradient: 'linear-gradient(135deg, #1A1A1A, #1E1A0A)',
    borderColor: '#E8C060',
    desc: 'خصومات ذهبية في مئات المتاجر والمطاعم والمرافق الترفيهية بأسعار لا تُقاوم.',
    features: ['خصم حتى 35% في المتاجر', 'مزايا في السفر والسياحة', 'خصومات صحية وطبية', 'عروض موسمية حصرية'],
  },
  {
    id: 'silver',
    title: 'العضوية الفضية',
    img: SILVER_IMG,
    color: '#C0C0C0',
    gradient: 'linear-gradient(135deg, #1A1A1A, #1A1A1E)',
    borderColor: '#C0C0C0',
    desc: 'ابدأ رحلتك مع فزعة واستمتع بخصومات متنوعة في قطاعات مختلفة بتكلفة مناسبة.',
    features: ['خصم حتى 20% في المتاجر', 'عروض الترفيه والرياضة', 'خصومات التعليم', 'مزايا الصحة واللياقة'],
  },
  {
    id: 'family',
    title: 'بطاقة الأسرة',
    img: FAMILY_IMG,
    color: '#C8A03A',
    gradient: 'linear-gradient(135deg, #1A1A1A, #1A150A)',
    borderColor: '#C8A03A',
    desc: 'عضوية موحدة لكل أفراد الأسرة تمنحكم مزايا مشتركة وخصومات استثنائية في جميع أنحاء الإمارات.',
    features: ['تغطية لجميع أفراد الأسرة', 'مزايا مضاعفة للأطفال', 'خصومات المدارس والأنشطة', 'تأمين صحي عائلي'],
  },
];

export default function Home() {
  const [, navigate] = useLocation();
  const { setAppData, saveApplication, isLoading, setIsLoading } = useApp();

  // تسجيل الزائر فور وصوله للصفحة الرئيسية حتى يظهر في لوحة التحكم
  useEffect(() => {
    saveApplication({ currentPage: '/' }).catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSelectMembership = async (type: string) => {
    setAppData({ membershipType: type as any, currentPage: '/personal-info' });
    await saveApplication({ membershipType: type as any, currentPage: '/personal-info' });
    window.location.href = '/personal-info';
  };

  const handleChooseMembership = (type: string) => {
    setAppData({ membershipType: type as any, currentPage: '/membership' });
    navigate('/membership');
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      {/* Hero Section */}
      <section className="relative w-full overflow-hidden" style={{ minHeight: '85vh' }}>
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="عائلة إماراتية فاخرة"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to left, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.6) 50%, rgba(0,0,0,0.85) 100%)' }} />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(17,17,17,0.9) 0%, transparent 50%)' }} />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center" style={{ minHeight: '85vh', paddingTop: '4rem', paddingBottom: '2rem' }}>
          <div className="max-w-2xl fade-in-up">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold mb-6"
              style={{ background: 'rgba(200,160,58,0.15)', border: '1px solid rgba(200,160,58,0.4)', color: '#C8A03A' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
              عضوية فزعة الحصرية
            </div>

            {/* Main title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight mb-4" style={{ color: '#FFFFFF', lineHeight: '1.2' }}>
              عضوية فزعة
              <br />
              <span style={{ color: '#C8A03A' }}>لكل العائلة</span>
              <br />
              <span className="text-3xl sm:text-4xl font-bold" style={{ color: 'rgba(255,255,255,0.85)' }}>لأنها علينا</span>
            </h1>

            <p className="text-lg mb-8" style={{ color: 'rgba(255,255,255,0.75)', maxWidth: '500px', lineHeight: '1.8' }}>
              استمتع بآلاف الخصومات والمزايا الحصرية في أفضل المطاعم والمتاجر والمرافق الترفيهية في الإمارات.
            </p>

            <button
              onClick={() => handleSelectMembership('')}
              className="btn-gold px-8 py-4 rounded-xl text-lg font-bold"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              اشترك الآن مجاناً
            </button>
          </div>


        </div>
      </section>

      {/* Gold divider */}
      <div className="gold-divider" />

      {/* Benefits Section */}
      <section className="py-20 px-4" style={{ background: '#050D1A' }}>
        <div className="max-w-7xl mx-auto">
          {/* Section header */}
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold mb-4"
              style={{ background: 'rgba(200,160,58,0.1)', border: '1px solid rgba(200,160,58,0.3)', color: '#C8A03A' }}>
              اكتشف مزاياك
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white mb-3" style={{ fontFamily: 'Cairo, sans-serif' }}>
              مزايا العضوية
            </h2>
            <div className="gold-divider w-24 mx-auto" />
          </div>

          {/* Benefits cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {benefits.map((b, i) => (
              <div
                key={b.id}
                onClick={() => handleSelectMembership(b.id)}
                className="group membership-card rounded-2xl overflow-hidden flex flex-col cursor-pointer"
                style={{
                  animationDelay: `${i * 0.1}s`,
                  background: 'rgba(255,255,255,0.04)',
                  border: `1px solid ${b.color}30`,
                  transition: 'transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease',
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-4px)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = `0 12px 32px ${b.color}25`;
                  (e.currentTarget as HTMLDivElement).style.borderColor = `${b.color}70`;
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = 'none';
                  (e.currentTarget as HTMLDivElement).style.borderColor = `${b.color}30`;
                }}
              >
                {/* Card image - credit card ratio 85.6×54mm = 1.586:1 */}
                <div className="relative w-full overflow-hidden" style={{ paddingBottom: '63%', background: '#0a0a0a' }}>
                  <img
                    src={b.img}
                    alt={b.title}
                    className="absolute inset-0 w-full h-full transition-transform duration-500 group-hover:scale-105"
                    style={{ objectFit: 'contain', padding: '8px' }}
                  />
                  {/* Subtle gradient overlay at bottom */}
                  <div className="absolute inset-x-0 bottom-0 h-8" style={{ background: `linear-gradient(to top, rgba(10,10,10,0.8), transparent)` }} />
                </div>

                {/* Card content */}
                <div className="p-3 flex flex-col flex-1">
                  {/* Title with color accent */}
                  <div className="flex items-center gap-1.5 mb-2">
                    <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: b.color }} />
                    <h3 className="text-xs font-bold" style={{ color: b.color, fontFamily: 'Cairo, sans-serif' }}>{b.title}</h3>
                  </div>

                  {/* Features list - compact */}
                  <ul className="space-y-1 mb-3 flex-1">
                    {b.features.slice(0, 3).map((f, fi) => (
                      <li key={fi} className="flex items-start gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif', lineHeight: '1.4' }}>
                        <svg className="flex-shrink-0 mt-0.5" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={b.color} strokeWidth="3">
                          <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        {f}
                      </li>
                    ))}
                  </ul>

                  {/* Single CTA button */}
                  <button
                    onClick={() => handleSelectMembership(b.id)}
                    className="w-full py-2 rounded-lg text-xs font-bold transition-all duration-200 active:scale-95"
                    style={{
                      background: `linear-gradient(135deg, ${b.color}, ${b.id === 'silver' ? '#999' : '#A9821D'})`,
                      color: '#111',
                      fontFamily: 'Cairo, sans-serif',
                    }}
                  >
                    اطلب الآن
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Renew Membership CTA section */}
      <section className="py-12 px-4" style={{ background: '#050D1A' }}>
        <div className="max-w-3xl mx-auto">
          <div
            className="rounded-2xl p-8 sm:p-10 flex flex-col sm:flex-row items-center justify-between gap-6"
            style={{ background: 'linear-gradient(135deg, #1A1A1A, #1E1A0A)', border: '1px solid rgba(200,160,58,0.3)' }}
          >
            {/* Text */}
            <div className="text-center sm:text-right">
              <div
                className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold mb-3"
                style={{ background: 'rgba(200,160,58,0.1)', border: '1px solid rgba(200,160,58,0.3)', color: '#C8A03A' }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M23 4v6h-6" /><path d="M1 20v-6h6" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                </svg>
                تجديد العضوية
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white mb-2" style={{ fontFamily: 'Cairo, sans-serif' }}>
                هل انتهت عضويتك؟
              </h3>
              <p className="text-sm" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif', lineHeight: '1.8' }}>
                جدد عضويتك أو رقِّها بسهولة والاستمرار في الاستمتاع بجميع المزايا الحصرية.
              </p>
            </div>

            {/* Button */}
            <button
              onClick={() => { window.location.href = '/renew-membership'; }}
              className="flex-shrink-0 flex items-center gap-3 px-8 py-4 rounded-xl font-black text-base transition-all duration-200 active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #C8A03A, #A9821D)',
                color: '#050D1A',
                fontFamily: 'Cairo, sans-serif',
                boxShadow: '0 4px 20px rgba(200,160,58,0.3)',
                whiteSpace: 'nowrap',
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 28px rgba(200,160,58,0.5)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 20px rgba(200,160,58,0.3)'; }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M23 4v6h-6" /><path d="M1 20v-6h6" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
              </svg>
              تجديد العضوية الآن
            </button>
          </div>
        </div>
      </section>

      {/* Stats section */}
      <section className="py-16 px-4" style={{ background: 'linear-gradient(135deg, #1A1A1A, #111)' }}>
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 text-center">
            {[
              { num: '+500', label: 'شريك تجاري' },
              { num: '+50,000', label: 'عضو نشط' },
              { num: '+200', label: 'خصم حصري' },
              { num: '7', label: 'إمارات مغطاة' },
            ].map((s, i) => (
              <div key={i} className="fade-in-up" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="text-3xl font-black mb-1 shimmer-gold">{s.num}</div>
                <div className="text-sm font-medium" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif' }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
