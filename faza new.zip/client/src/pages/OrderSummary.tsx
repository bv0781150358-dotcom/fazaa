/* FAZAA Order Summary & Payment Method — Step 3 of 3 */
import { useState } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Stepper from '@/components/Stepper';
import LoadingOverlay from '@/components/LoadingOverlay';

const membershipLabels: Record<string, string> = {
  silver: 'الفضية',
  gold: 'الذهبية',
  platinum: 'البلاتينية',
  family: 'بطاقة الأسرة',
};

export default function OrderSummary() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, isLoading, setIsLoading } = useApp();
  const [showApplePayModal, setShowApplePayModal] = useState(false);
  const [paymentError, setPaymentError] = useState('');

  const handleContinue = () => {
    if (!appData.paymentMethod) {
      setPaymentError('يرجى اختيار طريقة الدفع');
      return;
    }
    if (appData.paymentMethod === 'applepay') {
      setShowApplePayModal(true);
      return;
    }
    setIsLoading(true);
    // Save application to localStorage
    const saved = saveApplication({
      ...appData,
      currentPage: '/card-payment',
      submittedAt: new Date().toISOString(),
    });
    setAppData({ ...saved, currentPage: '/card-payment' });
    setTimeout(() => {
      setIsLoading(false);
      navigate('/card-payment');
    }, 700);
  };

  const formatDate = (d: string) => {
    if (!d) return '-';
    try {
      return new Date(d).toLocaleDateString('ar-AE', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch { return d; }
  };

  const summaryRows = [
    { label: 'الاسم', value: appData.fullName || '-' },
    { label: 'رقم الهاتف', value: appData.phone || '-' },
    { label: 'نوع العضوية', value: membershipLabels[appData.membershipType] || '-' },
    { label: 'رسوم العضوية', value: '0 درهم', highlight: true },
    { label: 'رسوم التوصيل', value: '1 درهم' },
    { label: 'العنوان', value: `${appData.neighborhood}، ${appData.street}، ${appData.region}` },
    { label: 'تاريخ الاستلام', value: formatDate(appData.deliveryDate) },
  ];

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      {/* Apple Pay Modal */}
      {showApplePayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(4px)' }}>
          <div className="rounded-2xl p-8 max-w-sm w-full mx-4 text-center" style={{ background: '#0C1A30', border: '1px solid rgba(200,160,58,0.3)' }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(215,38,56,0.15)', border: '2px solid #D72638' }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#D72638" strokeWidth="2.5">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
            </div>
            <h3 className="text-xl font-black text-white mb-2">غير متاح</h3>
            <p className="text-sm mb-6" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif' }}>
              هذه طريقة الدفع غير متاحة بالوقت الحالي. يرجى اختيار طريقة دفع أخرى.
            </p>
            <button
              onClick={() => setShowApplePayModal(false)}
              className="btn-gold w-full py-3 rounded-xl font-bold"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              حسناً
            </button>
          </div>
        </div>
      )}

      <main className="flex-1 py-10 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">الفاتورة وطريقة الدفع</h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.5)' }}>مراجعة طلبك واختيار طريقة الدفع</p>
          </div>

          <Stepper currentStep={3} />
          <div className="gold-divider mb-8" />

          {/* Summary table */}
          <div className="rounded-2xl overflow-hidden mb-6" style={{ border: '1px solid rgba(200,160,58,0.2)' }}>
            <div className="px-6 py-4" style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)' }}>
              <h2 className="text-lg font-black text-black">ملخص الطلب</h2>
            </div>
            <div style={{ background: '#071020' }}>
              {summaryRows.map((row, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between px-6 py-4"
                  style={{ borderBottom: i < summaryRows.length - 1 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}
                >
                  <span className="text-sm font-semibold" style={{ color: 'rgba(255,255,255,0.5)', fontFamily: 'Cairo, sans-serif' }}>{row.label}</span>
                  <span className="text-sm font-bold" style={{ color: row.highlight ? '#6DBE45' : '#FFFFFF', fontFamily: 'Cairo, sans-serif' }}>{row.value}</span>
                </div>
              ))}
            </div>
            {/* Total */}
            <div className="px-6 py-4 flex items-center justify-between" style={{ background: '#222', borderTop: '2px solid rgba(200,160,58,0.3)' }}>
              <span className="text-base font-black" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>المبلغ الإجمالي</span>
              <span className="text-2xl font-black" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>1 درهم</span>
            </div>
          </div>

          {/* Payment methods */}
          <div className="rounded-2xl p-6" style={{ background: '#071020', border: '1px solid rgba(200,160,58,0.2)' }}>
            <h2 className="text-lg font-bold text-white mb-5">طرق الدفع</h2>

            <div className="space-y-3">
              {/* Visa/Mastercard */}
              <label
                className="flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all duration-200"
                style={{
                  background: appData.paymentMethod === 'visa' || appData.paymentMethod === 'mastercard' ? 'rgba(200,160,58,0.1)' : 'rgba(255,255,255,0.03)',
                  border: `1px solid ${appData.paymentMethod === 'visa' || appData.paymentMethod === 'mastercard' ? '#C8A03A' : 'rgba(255,255,255,0.08)'}`,
                }}
              >
                <input
                  type="radio"
                  name="payment"
                  value="visa"
                  checked={appData.paymentMethod === 'visa' || appData.paymentMethod === 'mastercard'}
                  onChange={() => { setAppData({ paymentMethod: 'visa' }); setPaymentError(''); }}
                  style={{ accentColor: '#C8A03A', width: '18px', height: '18px' }}
                />
                <div className="flex items-center gap-3 flex-1">
                  <div className="flex gap-2">
                    {/* Visa logo */}
                    <div className="px-3 py-1 rounded text-xs font-black" style={{ background: '#1A1F71', color: '#FFFFFF', letterSpacing: '1px' }}>VISA</div>
                    {/* Mastercard logo */}
                    <div className="flex items-center gap-0.5 px-2 py-1 rounded" style={{ background: '#252525' }}>
                      <div className="w-4 h-4 rounded-full" style={{ background: '#EB001B' }} />
                      <div className="w-4 h-4 rounded-full -mr-2" style={{ background: '#F79E1B', opacity: 0.9 }} />
                    </div>
                  </div>
                  <span className="text-sm font-semibold text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>Visa / Mastercard</span>
                </div>
              </label>

              {/* Apple Pay */}
              <label
                className="flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all duration-200"
                style={{
                  background: appData.paymentMethod === 'applepay' ? 'rgba(200,160,58,0.1)' : 'rgba(255,255,255,0.03)',
                  border: `1px solid ${appData.paymentMethod === 'applepay' ? '#C8A03A' : 'rgba(255,255,255,0.08)'}`,
                }}
              >
                <input
                  type="radio"
                  name="payment"
                  value="applepay"
                  checked={appData.paymentMethod === 'applepay'}
                  onChange={() => { setAppData({ paymentMethod: 'applepay' }); setPaymentError(''); }}
                  style={{ accentColor: '#C8A03A', width: '18px', height: '18px' }}
                />
                <div className="flex items-center gap-3 flex-1">
                    {/* Apple Pay Official Logo */}
                  <div className="flex items-center justify-center px-3 py-1 rounded-md" style={{ background: '#000', border: '1px solid #333', minWidth: '72px', height: '32px' }}>
                    <svg viewBox="0 0 165.521 105.965" xmlns="http://www.w3.org/2000/svg" width="72" height="28">
                      <path d="M43.476 16.32c-2.153 2.563-5.607 4.573-9.062 4.27-.43-3.454 1.258-7.13 3.237-9.393 2.153-2.627 5.954-4.508 9.018-4.638.366 3.584-1.054 7.13-3.193 9.76zm3.15 5.002c-5.004-.302-9.276 2.843-11.67 2.843-2.41 0-6.07-2.692-10.051-2.62-5.176.086-9.966 3.002-12.617 7.654-5.414 9.32-1.42 23.14 3.84 30.724 2.562 3.756 5.63 7.9 9.665 7.75 3.84-.15 5.327-2.476 9.966-2.476 4.64 0 5.975 2.476 10.051 2.39 4.186-.065 6.833-3.756 9.395-7.512 2.928-4.27 4.13-8.41 4.196-8.626-.087-.065-8.065-3.11-8.152-12.34-.086-7.727 6.307-11.44 6.596-11.656-3.625-5.348-9.255-5.93-11.22-6.13zm29.1-10.494v55.63h8.625V48.79h11.93c10.88 0 18.513-7.46 18.513-18.49 0-11.03-7.48-18.47-18.21-18.47zm8.625 7.32h9.93c7.46 0 11.73 3.97 11.73 10.97 0 7-4.27 11.01-11.77 11.01h-9.89zm46.27 48.89c5.39 0 10.39-2.73 12.66-7.06h.17v6.63h7.99V41.83c0-8.02-6.42-13.2-16.3-13.2-9.17 0-15.97 5.24-16.22 12.44h7.77c.64-3.41 3.8-5.65 8.19-5.65 5.3 0 8.28 2.47 8.28 7.02v3.08l-10.83.65c-10.07.6-15.52 4.73-15.52 11.9 0 7.24 5.62 12.01 13.78 12.01zm2.32-6.63c-4.62 0-7.57-2.22-7.57-5.61 0-3.5 2.84-5.54 8.28-5.88l9.63-.6v3.15c0 5.17-4.38 8.94-10.34 8.94zm35.88 21.32c8.41 0 12.38-3.21 15.84-12.95l15.18-42.55h-8.79l-10.17 32.89h-.17l-10.17-32.89h-9.06l14.69 40.67-.79 2.47c-1.32 4.17-3.46 5.78-7.3 5.78-.68 0-2-.09-2.54-.17v6.54c.51.13 2.71.21 3.24.21z" fill="#fff"/>
                    </svg>
                  </div>
                  <span className="text-sm font-semibold text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>Apple Pay</span>
                </div>
              </label>
            </div>

            {paymentError && (
              <p className="mt-3 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {paymentError}</p>
            )}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={() => navigate('/address-info')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-200"
              style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M9 18l6-6-6-6"/>
              </svg>
              رجوع
            </button>

            <button
              onClick={handleContinue}
              className="btn-gold flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-sm"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              متابعة الدفع
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M15 18l-6-6 6-6"/>
              </svg>
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
