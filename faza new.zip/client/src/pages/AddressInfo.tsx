/* FAZAA Address Info — Step 2 of 3 (Address) */
import { useState } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Stepper from '@/components/Stepper';
import LoadingOverlay from '@/components/LoadingOverlay';

const UAE_REGIONS = [
  'أبوظبي', 'دبي', 'الشارقة', 'عجمان', 'أم القيوين', 'رأس الخيمة', 'الفجيرة',
  'العين', 'الظفرة', 'مدينة خليفة', 'مصفح', 'الريف', 'محمد بن زايد',
];

interface Errors {
  region?: string;
  street?: string;
  neighborhood?: string;
  deliveryDate?: string;
}

export default function AddressInfo() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, isLoading, setIsLoading } = useApp();
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const validate = (): boolean => {
    const errs: Errors = {};
    if (!appData.region) errs.region = 'يرجى اختيار المنطقة';
    if (!appData.street.trim() || appData.street.trim().length < 3) errs.street = 'يرجى إدخال اسم الشارع';
    if (!appData.neighborhood.trim() || appData.neighborhood.trim().length < 2) errs.neighborhood = 'يرجى إدخال اسم الحي';
    if (!appData.deliveryDate) errs.deliveryDate = 'يرجى اختيار موعد الاستلام';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    setTouched({ region: true, street: true, neighborhood: true, deliveryDate: true });
    if (!validate()) return;
    setIsLoading(true);
    // بناء كائن البيانات مباشرة بدون الاعتماد على React state غير المتزامن
    const freshData = { ...appData, currentPage: '/order-summary', submittedAt: appData.submittedAt || new Date().toISOString() };
    setAppData(freshData);
    saveApplication(freshData).catch(console.error);
    setTimeout(() => {
      setIsLoading(false);
      navigate('/order-summary');
    }, 600);
  };

  const inputStyle = (field: keyof Errors) => ({
    background: '#071020',
    border: `1px solid ${touched[field] && errors[field] ? '#D72638' : 'rgba(200,160,58,0.3)'}`,
    borderRadius: '10px',
    color: '#FFFFFF',
    fontFamily: 'Cairo, sans-serif',
    padding: '12px 16px',
    width: '100%',
    fontSize: '15px',
    outline: 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  });

  // Min date: today
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 py-10 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">كن عضواً</h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.5)' }}>أدخل معلومات العنوان وموعد الاستلام</p>
          </div>

          <Stepper currentStep={2} />
          <div className="gold-divider mb-8" />

          {/* Form card */}
          <div className="rounded-2xl p-6 sm:p-8" style={{ background: '#071020', border: '1px solid rgba(200,160,58,0.2)' }}>
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)', color: '#111' }}>2</span>
              معلومات العنوان
            </h2>

            <div className="space-y-5">
              {/* Region */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  المنطقة <span style={{ color: '#D72638' }}>*</span>
                </label>
                <select
                  value={appData.region}
                  onChange={e => {
                    setAppData({ region: e.target.value });
                    if (touched.region) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, region: true })); validate(); }}
                  style={{ ...inputStyle('region'), appearance: 'none', cursor: 'pointer' }}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                >
                  <option value="" style={{ background: '#071020' }}>اختر المنطقة</option>
                  {UAE_REGIONS.map(r => (
                    <option key={r} value={r} style={{ background: '#071020' }}>{r}</option>
                  ))}
                </select>
                {touched.region && errors.region && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.region}</p>
                )}
              </div>

              {/* Street */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  الشارع <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="اسم الشارع أو رقمه"
                  value={appData.street}
                  onChange={e => {
                    setAppData({ street: e.target.value });
                    if (touched.street) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, street: true })); validate(); }}
                  style={inputStyle('street')}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                />
                {touched.street && errors.street && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.street}</p>
                )}
              </div>

              {/* Neighborhood */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  الحي <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="اسم الحي أو المجمع السكني"
                  value={appData.neighborhood}
                  onChange={e => {
                    setAppData({ neighborhood: e.target.value });
                    if (touched.neighborhood) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, neighborhood: true })); validate(); }}
                  style={inputStyle('neighborhood')}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                />
                {touched.neighborhood && errors.neighborhood && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.neighborhood}</p>
                )}
              </div>

              {/* Delivery Date */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  موعد الاستلام <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="date"
                  min={today}
                  value={appData.deliveryDate}
                  onChange={e => {
                    setAppData({ deliveryDate: e.target.value });
                    if (touched.deliveryDate) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, deliveryDate: true })); validate(); }}
                  style={{ ...inputStyle('deliveryDate'), direction: 'ltr', textAlign: 'right', colorScheme: 'dark' }}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                />
                {touched.deliveryDate && errors.deliveryDate && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.deliveryDate}</p>
                )}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={() => navigate('/personal-info')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-200"
              style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M9 18l6-6-6-6"/>
              </svg>
              رجوع
            </button>

            <button
              onClick={handleNext}
              className="btn-gold flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-sm"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              التالي
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M15 18l-6-6 6-6"/>
              </svg>
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
