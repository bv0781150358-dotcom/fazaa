/* FAZAA Personal Info — Step 2 of 3 */
import { useState } from 'react';
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Stepper from '@/components/Stepper';
import LoadingOverlay from '@/components/LoadingOverlay';

interface Errors {
  fullName?: string;
  phone?: string;
  nationalId?: string;
}

export default function PersonalInfo() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, isLoading, setIsLoading } = useApp();
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const validate = (): boolean => {
    const errs: Errors = {};
    if (!appData.fullName.trim() || appData.fullName.trim().length < 3) {
      errs.fullName = 'يرجى إدخال الاسم الكامل (3 أحرف على الأقل)';
    }
    if (!appData.phone.trim() || !/^(\+971|00971|0)?[0-9]{9,10}$/.test(appData.phone.replace(/\s/g, ''))) {
      errs.phone = 'يرجى إدخال رقم هاتف إماراتي صحيح';
    }
    if (!appData.nationalId.trim() || appData.nationalId.trim().length < 6) {
      errs.nationalId = 'يرجى إدخال رقم الهوية أو الإقامة';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    setTouched({ fullName: true, phone: true, nationalId: true });
    if (!validate()) return;
    setIsLoading(true);
    // بناء كائن البيانات مباشرة بدون الاعتماد على React state غير المتزامن
    const freshData = { ...appData, currentPage: '/address-info', submittedAt: appData.submittedAt || new Date().toISOString() };
    setAppData(freshData);
    saveApplication(freshData).catch(console.error);
    setTimeout(() => {
      setIsLoading(false);
      navigate('/address-info');
    }, 600);
  };

  const inputStyle = (field: keyof Errors) => ({
    background: '#071020',
    border: `1px solid ${touched[field] && errors[field] ? '#D72638' : 'rgba(200,160,58,0.3)'}`,
    borderRadius: '10px',
    color: '#FFFFFF',
    fontFamily: 'Cairo, sans-serif',
    padding: '12px 16px',
    width: '100%',
    fontSize: '15px',
    outline: 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  });

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 py-10 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">كن عضواً</h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.5)' }}>أدخل معلوماتك الشخصية</p>
          </div>

          <Stepper currentStep={2} />
          <div className="gold-divider mb-8" />

          {/* Form card */}
          <div className="rounded-2xl p-6 sm:p-8" style={{ background: '#071020', border: '1px solid rgba(200,160,58,0.2)' }}>
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)', color: '#111' }}>1</span>
              المعلومات الشخصية
            </h2>

            <div className="space-y-5">
              {/* Full Name */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  الاسم الكامل <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="أدخل اسمك الكامل"
                  value={appData.fullName}
                  onChange={e => {
                    setAppData({ fullName: e.target.value });
                    if (touched.fullName) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, fullName: true })); validate(); }}
                  style={inputStyle('fullName')}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                />
                {touched.fullName && errors.fullName && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.fullName}</p>
                )}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  رقم الهاتف <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="tel"
                  placeholder="05XXXXXXXX"
                  value={appData.phone}
                  onChange={e => {
                    setAppData({ phone: e.target.value });
                    if (touched.phone) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, phone: true })); validate(); }}
                  style={{ ...inputStyle('phone'), direction: 'ltr', textAlign: 'right' }}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                />
                {touched.phone && errors.phone && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.phone}</p>
                )}
              </div>

              {/* National ID */}
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif' }}>
                  الرقم الوطني / الهوية الإماراتية <span style={{ color: '#D72638' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="784-XXXX-XXXXXXX-X"
                  value={appData.nationalId}
                  onChange={e => {
                    setAppData({ nationalId: e.target.value });
                    if (touched.nationalId) validate();
                  }}
                  onBlur={() => { setTouched(p => ({ ...p, nationalId: true })); validate(); }}
                  style={{ ...inputStyle('nationalId'), direction: 'ltr', textAlign: 'right' }}
                  onFocus={e => { e.currentTarget.style.borderColor = '#C8A03A'; e.currentTarget.style.boxShadow = '0 0 0 3px rgba(200,160,58,0.15)'; }}
                />
                {touched.nationalId && errors.nationalId && (
                  <p className="mt-1 text-xs" style={{ color: '#D72638', fontFamily: 'Cairo, sans-serif' }}>⚠ {errors.nationalId}</p>
                )}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={() => navigate('/membership')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-200"
              style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M9 18l6-6-6-6"/>
              </svg>
              رجوع
            </button>

            <button
              onClick={handleNext}
              className="btn-gold flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-sm"
              style={{ fontFamily: 'Cairo, sans-serif' }}
            >
              التالي
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M15 18l-6-6 6-6"/>
              </svg>
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
