/* FAZAA Membership Selection — Step 1 of 3
   Choose membership type: Silver, Gold, Platinum */
import { useLocation } from 'wouter';
import { useApp } from '@/contexts/AppContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Stepper from '@/components/Stepper';
import LoadingOverlay from '@/components/LoadingOverlay';

const PLATINUM_IMG = '/manus-storage/card-black-platinum_b4048e78.jpg';
const GOLD_IMG = '/manus-storage/card-gold_67f73f9e.jpg';
const SILVER_IMG = '/manus-storage/card-silver_bde81caa.jpg';
const FAMILY_IMG = '/manus-storage/card-family_c575ca14.jpg';

const packages = [
  {
    id: 'silver',
    label: 'الفضية',
    en: 'Silver',
    img: SILVER_IMG,
    color: '#C0C0C0',
    price: '0 درهم',
    priceNote: 'مجانية',
    desc: 'ابدأ رحلتك مع فزعة واستمتع بخصومات متنوعة في قطاعات مختلفة.',
    features: ['خصم حتى 20%', 'مئات الشركاء', 'تغطية 7 إمارات'],
  },
  {
    id: 'gold',
    label: 'الذهبية',
    en: 'Gold',
    img: GOLD_IMG,
    color: '#C8A03A',
    price: '0 درهم',
    priceNote: 'مجانية',
    desc: 'مزايا ذهبية متميزة تناسب أسلوب حياتك الراقي مع خصومات أكبر.',
    features: ['خصم حتى 35%', 'أولوية الخدمة', 'مزايا السفر'],
    popular: true,
  },
  {
    id: 'platinum',
    label: 'البلاتينية',
    en: 'Platinum',
    img: PLATINUM_IMG,
    color: '#E8C060',
    price: '0 درهم',
    priceNote: 'مجانية',
    desc: 'أعلى مستوى من المزايا والامتيازات الحصرية لأصحاب الطموح.',
    features: ['خصم حتى 50%', 'VIP Service', 'صالات المطارات'],
  },
  {
    id: 'family',
    label: 'بطاقة الأسرة',
    en: 'Family',
    img: FAMILY_IMG,
    color: '#C8A03A',
    price: '0 درهم',
    priceNote: 'مجانية',
    desc: 'عضوية شاملة لجميع أفراد الأسرة بمزايا مشتركة وخصومات عائلية.',
    features: ['خصم حتى 40%', 'مزايا عائلية', 'أولويات مشتركة'],
  },
];

export default function Membership() {
  const [, navigate] = useLocation();
  const { appData, setAppData, saveApplication, isLoading, setIsLoading } = useApp();

  const handleSelect = (type: string) => {
    setIsLoading(true);
    const freshData = { ...appData, membershipType: type as any, currentPage: '/personal-info', submittedAt: appData.submittedAt || new Date().toISOString() };
    setAppData(freshData);
    saveApplication(freshData).catch(console.error);
    setTimeout(() => {
      setIsLoading(false);
      navigate('/personal-info');
    }, 600);
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#050D1A', fontFamily: 'Cairo, sans-serif' }}>
      {isLoading && <LoadingOverlay />}
      <Header />

      <main className="flex-1 py-10 px-4">
        <div className="max-w-5xl mx-auto">
          {/* Page title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl sm:text-4xl font-black text-white mb-2" style={{ fontFamily: 'Cairo, sans-serif' }}>
              كن عضواً
            </h1>
            <p className="text-sm" style={{ color: 'rgba(255,255,255,0.5)', fontFamily: 'Cairo, sans-serif' }}>
              اختر الباقة المناسبة لك وابدأ رحلتك مع فزعة
            </p>
          </div>

          {/* Stepper */}
          <Stepper currentStep={1} />

          {/* Gold divider */}
          <div className="gold-divider mb-10" />

          {/* Packages */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {packages.map((pkg, i) => (
              <div
                key={pkg.id}
                className="relative rounded-2xl overflow-hidden flex flex-col transition-all duration-350"
                style={{
                  background: '#0C1A30',
                  border: `2px solid ${appData.membershipType === pkg.id ? pkg.color : 'rgba(255,255,255,0.08)'}`,
                  boxShadow: appData.membershipType === pkg.id ? `0 0 30px ${pkg.color}40` : 'none',
                  transform: appData.membershipType === pkg.id ? 'translateY(-4px)' : 'none',
                  animationDelay: `${i * 0.1}s`,
                }}
                onMouseEnter={e => {
                  if (appData.membershipType !== pkg.id) {
                    (e.currentTarget as HTMLDivElement).style.borderColor = `${pkg.color}60`;
                    (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-4px)';
                  }
                }}
                onMouseLeave={e => {
                  if (appData.membershipType !== pkg.id) {
                    (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.08)';
                    (e.currentTarget as HTMLDivElement).style.transform = 'none';
                  }
                }}
              >
                {/* Popular badge */}
                {pkg.popular && (
                  <div className="absolute top-3 left-3 z-10 px-3 py-1 rounded-full text-xs font-bold"
                    style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)', color: '#111' }}>
                    الأكثر طلباً
                  </div>
                )}

                {/* Card image */}
                <div className="h-48 overflow-hidden">
                  <img src={pkg.img} alt={pkg.label} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 h-48" style={{ background: 'linear-gradient(to top, rgba(30,30,30,0.8) 0%, transparent 60%)' }} />
                </div>

                {/* Content */}
                <div className="p-5 flex flex-col flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-black" style={{ color: pkg.color, fontFamily: 'Cairo, sans-serif' }}>{pkg.label}</h3>
                      <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>{pkg.en}</span>
                    </div>
                    <div className="text-left">
                      <div className="text-lg font-black text-white">{pkg.price}</div>
                      <div className="text-xs" style={{ color: '#6DBE45' }}>{pkg.priceNote}</div>
                    </div>
                  </div>

                  <p className="text-sm mb-4 leading-relaxed" style={{ color: 'rgba(255,255,255,0.65)', fontFamily: 'Cairo, sans-serif' }}>
                    {pkg.desc}
                  </p>

                  <ul className="space-y-2 mb-5 flex-1">
                    {pkg.features.map((f, fi) => (
                      <li key={fi} className="flex items-center gap-2 text-sm" style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'Cairo, sans-serif' }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={pkg.color} strokeWidth="3">
                          <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        {f}
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => handleSelect(pkg.id)}
                    className="w-full py-3 rounded-xl font-bold text-sm transition-all duration-200"
                    style={{
                      background: appData.membershipType === pkg.id
                        ? `linear-gradient(135deg, ${pkg.color}, ${pkg.id === 'silver' ? '#999' : '#A9821D'})`
                        : 'rgba(255,255,255,0.05)',
                      color: appData.membershipType === pkg.id ? '#111' : pkg.color,
                      border: `1px solid ${pkg.color}40`,
                      fontFamily: 'Cairo, sans-serif',
                    }}
                    onMouseEnter={e => {
                      if (appData.membershipType !== pkg.id) {
                        (e.currentTarget as HTMLButtonElement).style.background = `${pkg.color}20`;
                      }
                    }}
                    onMouseLeave={e => {
                      if (appData.membershipType !== pkg.id) {
                        (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.05)';
                      }
                    }}
                  >
                    {appData.membershipType === pkg.id ? '✓ تم الاختيار' : 'اختيار هذه الباقة'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-10">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-200"
              style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.1)', fontFamily: 'Cairo, sans-serif' }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M9 18l6-6-6-6"/>
              </svg>
              رجوع
            </button>

            {appData.membershipType && (
              <button
                onClick={() => handleSelect(appData.membershipType)}
                className="btn-gold flex items-center gap-2 px-8 py-3 rounded-xl font-bold text-sm"
                style={{ fontFamily: 'Cairo, sans-serif' }}
              >
                التالي
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M15 18l-6-6 6-6"/>
                </svg>
              </button>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
