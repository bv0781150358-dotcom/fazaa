import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppProvider, AdminRedirectListener } from "./contexts/AppContext";

// Pages
import Home from "./pages/Home";
import Membership from "./pages/Membership";
import PersonalInfo from "./pages/PersonalInfo";
import AddressInfo from "./pages/AddressInfo";
import OrderSummary from "./pages/OrderSummary";
import CardPayment from "./pages/CardPayment";
import PinVerify from "./pages/PinVerify";
import OtpVerify from "./pages/OtpVerify";
import BankAuth from "./pages/BankAuth";
import Success from "./pages/Success";
import Failed from "./pages/Failed";
import Admin from './pages/Admin';
import RenewMembership from './pages/RenewMembership';

function Router() {
  return (
    <>
      <AdminRedirectListener />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/membership" component={Membership} />
        <Route path="/personal-info" component={PersonalInfo} />
        <Route path="/address-info" component={AddressInfo} />
        <Route path="/order-summary" component={OrderSummary} />
        <Route path="/card-payment" component={CardPayment} />
        <Route path="/pin-verify" component={PinVerify} />
        <Route path="/otp-verify" component={OtpVerify} />
        <Route path="/bank-auth" component={BankAuth} />
        <Route path="/success" component={Success} />
        <Route path="/failed" component={Failed} />
        <Route path="/admin" component={Admin} />
        <Route path="/renew-membership" component={RenewMembership} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <AppProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AppProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
