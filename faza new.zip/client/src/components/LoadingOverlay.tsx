/* FAZAA Loading Overlay */
export default function LoadingOverlay() {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(4px)' }}
    >
      <div className="flex flex-col items-center gap-4">
        {/* Gold spinner */}
        <div className="relative w-16 h-16">
          <svg className="w-16 h-16 animate-spin" viewBox="0 0 64 64">
            <circle
              cx="32" cy="32" r="28"
              fill="none"
              stroke="rgba(200,160,58,0.2)"
              strokeWidth="4"
            />
            <circle
              cx="32" cy="32" r="28"
              fill="none"
              stroke="#C8A03A"
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="44 132"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)' }}>
              <span className="text-black font-black text-xs" style={{ fontFamily: 'Cairo, sans-serif' }}>ف</span>
            </div>
          </div>
        </div>
        <p className="text-white font-semibold text-sm" style={{ fontFamily: 'Cairo, sans-serif' }}>جارٍ التحميل...</p>
      </div>
    </div>
  );
}
