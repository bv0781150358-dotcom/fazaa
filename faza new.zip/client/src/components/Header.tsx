/* FAZAA Header — Emirates Premium Banking + Dark Gold
   Full-width golden header with FAZAA logo and language toggle */
import { useApp } from '@/contexts/AppContext';
import { Link } from 'wouter';

export default function Header() {
  const { language, toggleLanguage } = useApp();

  return (
    <header className="w-full" style={{ background: 'linear-gradient(135deg, #C8A03A 0%, #A9821D 40%, #C8A03A 70%, #E8C060 100%)', boxShadow: '0 4px 20px rgba(200,160,58,0.4)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo - Right side (RTL) */}
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer group">
              {/* FAZAA Logo SVG */}
              <div className="w-14 h-14 rounded-xl flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.25)', border: '2px solid rgba(0,0,0,0.2)' }}>
                <svg width="40" height="40" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect width="100" height="100" rx="12" fill="#050D1A"/>
                  {/* Arabic ف ز ع ة stylized */}
                  <text x="50" y="62" textAnchor="middle" fill="#C8A03A" fontSize="42" fontWeight="900" fontFamily="Cairo, sans-serif">فزعة</text>
                </svg>
              </div>
              <div>
                <div className="text-2xl font-black text-black leading-none" style={{ fontFamily: 'Cairo, sans-serif', letterSpacing: '-0.5px' }}>
                  فـزعـة
                </div>
                <div className="text-xs font-bold text-black/70 tracking-widest uppercase">FAZAA</div>
              </div>
            </div>
          </Link>

          {/* Language Toggle - Left side (RTL) */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm transition-all duration-200"
            style={{
              background: 'rgba(0,0,0,0.2)',
              color: '#050D1A',
              border: '2px solid rgba(0,0,0,0.15)',
              fontFamily: 'Cairo, sans-serif',
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,0,0,0.35)';
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,0,0,0.2)';
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10"/>
              <path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
            </svg>
            {language === 'ar' ? 'English' : 'عربي'}
          </button>
        </div>
      </div>
    </header>
  );
}
