/* FAZAA Footer — Black with gold links */
import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer style={{ background: '#0A0A0A', borderTop: '1px solid rgba(200,160,58,0.2)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #C8A03A, #A9821D)' }}>
              <span className="text-black font-black text-sm" style={{ fontFamily: 'Cairo, sans-serif' }}>فزعة</span>
            </div>
            <span className="text-white font-bold text-lg" style={{ fontFamily: 'Cairo, sans-serif' }}>فزعة</span>
          </div>

          {/* Links */}
          <div className="flex items-center gap-6 flex-wrap justify-center">
            <a href="#" className="text-sm transition-colors duration-200" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif' }}
              onMouseEnter={e => (e.currentTarget as HTMLAnchorElement).style.color = '#C8A03A'}
              onMouseLeave={e => (e.currentTarget as HTMLAnchorElement).style.color = 'rgba(255,255,255,0.6)'}
            >
              سياسة الخصوصية
            </a>
            <span style={{ color: 'rgba(200,160,58,0.3)' }}>|</span>
            <a href="#" className="text-sm transition-colors duration-200" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif' }}
              onMouseEnter={e => (e.currentTarget as HTMLAnchorElement).style.color = '#C8A03A'}
              onMouseLeave={e => (e.currentTarget as HTMLAnchorElement).style.color = 'rgba(255,255,255,0.6)'}
            >
              شروط الخدمة
            </a>
            <span style={{ color: 'rgba(200,160,58,0.3)' }}>|</span>
            <a href="#" className="text-sm transition-colors duration-200" style={{ color: 'rgba(255,255,255,0.6)', fontFamily: 'Cairo, sans-serif' }}
              onMouseEnter={e => (e.currentTarget as HTMLAnchorElement).style.color = '#C8A03A'}
              onMouseLeave={e => (e.currentTarget as HTMLAnchorElement).style.color = 'rgba(255,255,255,0.6)'}
            >
              الأسئلة الشائعة
            </a>
          </div>

          {/* Copyright */}
          <div className="text-sm" style={{ color: 'rgba(255,255,255,0.4)', fontFamily: 'Cairo, sans-serif' }}>
            © 2026 فزعة. جميع الحقوق محفوظة.
          </div>
        </div>
      </div>
    </footer>
  );
}
