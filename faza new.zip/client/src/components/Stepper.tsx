/* FAZAA Stepper — 3-step registration flow */
interface StepperProps {
  currentStep: number; // 1, 2, or 3
}

const steps = [
  { label: 'معلومات شخصية', num: 1 },
  { label: 'معلومات العنوان', num: 2 },
  { label: 'الاشتراك', num: 3 },
];

export default function Stepper({ currentStep }: StepperProps) {
  return (
    <div className="w-full py-6">
      <div className="flex items-center justify-center gap-0">
        {steps.map((step, idx) => {
          const isDone = currentStep > step.num;
          const isActive = currentStep === step.num;
          const isLast = idx === steps.length - 1;

          return (
            <div key={step.num} className="flex items-center">
              {/* Step circle */}
              <div className="flex flex-col items-center gap-2">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300"
                  style={
                    isDone
                      ? { background: 'linear-gradient(135deg, #A9821D, #C8A03A)', color: '#111' }
                      : isActive
                      ? { background: 'linear-gradient(135deg, #1D4A91, #2563EB)', color: '#fff', boxShadow: '0 0 20px rgba(29,74,145,0.5)' }
                      : { background: '#0C1A30', color: '#666', border: '1px solid #333' }
                  }
                >
                  {isDone ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  ) : (
                    step.num
                  )}
                </div>
                <span
                  className="text-xs font-semibold whitespace-nowrap"
                  style={{
                    fontFamily: 'Cairo, sans-serif',
                    color: isDone ? '#C8A03A' : isActive ? '#fff' : '#555',
                  }}
                >
                  {step.label}
                </span>
              </div>

              {/* Connector line */}
              {!isLast && (
                <div
                  className="w-16 sm:w-24 h-0.5 mx-2 mb-6 transition-all duration-500"
                  style={{
                    background: isDone
                      ? 'linear-gradient(90deg, #C8A03A, #A9821D)'
                      : 'rgba(255,255,255,0.1)',
                  }}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
