import { describe, it, expect, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the db module
vi.mock("./db", () => ({
  upsertApplication: vi.fn().mockResolvedValue(undefined),
  getApplicationBySessionId: vi.fn().mockResolvedValue(null),
  getAllApplications: vi.fn().mockResolvedValue([]),
  updateApplicationStatus: vi.fn().mockResolvedValue(undefined),
  setAdminRedirect: vi.fn().mockResolvedValue(undefined),
  clearAdminRedirect: vi.fn().mockResolvedValue(undefined),
  deleteApplication: vi.fn().mockResolvedValue(undefined),
}));

import {
  upsertApplication,
  getApplicationBySessionId,
  getAllApplications,
  updateApplicationStatus,
  setAdminRedirect,
  clearAdminRedirect,
  deleteApplication,
} from "./db";

function createContext(): TrpcContext {
  return {
    req: {} as any,
    res: {} as any,
    user: null,
  };
}

describe("applications router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("upsert: يحفظ الطلب في قاعدة البيانات", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.upsert({
      sessionId: "sess_test_123",
      fullName: "محمد أحمد",
      phone: "0501234567",
      membershipType: "gold",
    });
    expect(result).toEqual({ success: true });
    expect(upsertApplication).toHaveBeenCalledOnce();
    const callArg = (upsertApplication as any).mock.calls[0][0];
    expect(callArg.sessionId).toBe("sess_test_123");
    expect(callArg.fullName).toBe("محمد أحمد");
  });

  it("getAll: يجلب جميع الطلبات", async () => {
    (getAllApplications as any).mockResolvedValue([
      { sessionId: "sess_1", fullName: "أحمد", status: "pending" },
    ]);
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.getAll();
    expect(result).toHaveLength(1);
    expect(result[0].fullName).toBe("أحمد");
  });

  it("getBySession: يجلب طلب بالـ sessionId", async () => {
    (getApplicationBySessionId as any).mockResolvedValue({
      sessionId: "sess_abc",
      fullName: "فاطمة",
      currentPage: "/card-payment",
    });
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.getBySession({ sessionId: "sess_abc" });
    expect(result?.fullName).toBe("فاطمة");
    expect(result?.currentPage).toBe("/card-payment");
  });

  it("updateStatus: يحدث حالة الطلب", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.updateStatus({
      sessionId: "sess_test",
      status: "approved",
    });
    expect(result).toEqual({ success: true });
    expect(updateApplicationStatus).toHaveBeenCalledWith("sess_test", "approved");
  });

  it("setRedirect: يضبط صفحة التوجيه", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.setRedirect({
      sessionId: "sess_test",
      page: "/otp-verify",
    });
    expect(result).toEqual({ success: true });
    expect(setAdminRedirect).toHaveBeenCalledWith("sess_test", "/otp-verify");
  });

  it("clearRedirect: يمسح صفحة التوجيه", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.clearRedirect({
      sessionId: "sess_test",
    });
    expect(result).toEqual({ success: true });
    expect(clearAdminRedirect).toHaveBeenCalledWith("sess_test");
  });

  it("delete: يحذف الطلب", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.applications.delete({
      sessionId: "sess_test",
    });
    expect(result).toEqual({ success: true });
    expect(deleteApplication).toHaveBeenCalledWith("sess_test");
  });
});
