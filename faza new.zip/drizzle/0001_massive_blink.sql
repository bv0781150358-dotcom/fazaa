ALTER TABLE `applications` ADD `renewalMembershipNumber` varchar(64);--> statement-breakpoint
ALTER TABLE `applications` ADD `currentMembershipType` varchar(32);